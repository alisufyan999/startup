export const BRAND_LOGOS = [
  {
    src: "/assets/images/logos/1.webp",
    alt: "Yahoo News",
  },
  {
    src: "/assets/images/logos/2.webp",
    alt: "Logotype",
  },
  {
    src: "/assets/images/logos/3.webp",
    alt: "Duragas Abastible",
  },
  {
    src: "/assets/images/logos/4.webp",
    alt: "Maxton Design",
  },
  {
    src: "/assets/images/logos/5.webp",
    alt: "Forbes",
  },
  {
    src: "/assets/images/logos/6.webp",
    alt: "Bloomberg",
  },
  {
    src: "/assets/images/logos/1.webp",
    alt: "Yahoo News",
  },
  {
    src: "/assets/images/logos/2.webp",
    alt: "Logotype",
  },
  {
    src: "/assets/images/logos/3.webp",
    alt: "Duragas Abastible",
  },
  {
    src: "/assets/images/logos/4.webp",
    alt: "Maxton Design",
  },
  {
    src: "/assets/images/logos/5.webp",
    alt: "Forbes",
  },
  {
    src: "/assets/images/logos/6.webp",
    alt: "Bloomberg",
  },
  {
    src: "/assets/images/logos/1.webp",
    alt: "Yahoo News",
  },
  {
    src: "/assets/images/logos/2.webp",
    alt: "Logotype",
  },
  {
    src: "/assets/images/logos/3.webp",
    alt: "Duragas Abastible",
  },
  {
    src: "/assets/images/logos/4.webp",
    alt: "Maxton Design",
  },
  {
    src: "/assets/images/logos/5.webp",
    alt: "Forbes",
  },
  {
    src: "/assets/images/logos/6.webp",
    alt: "Bloomberg",
  },
];

