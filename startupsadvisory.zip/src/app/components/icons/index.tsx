import React from "react";

export const ArrowRightIcon = ({ style }: { style?: React.CSSProperties }) => (
    <svg width="18" height="18" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
        <path d="m17.707 9.293-5-5a.999.999 0 1 0-1.414 1.414L14.586 9H3a1 1 0 1 0 0 2h11.586l-3.293 3.293a.999.999 0 1 0 1.414 1.414l5-5a1 1 0 0 0 0-1.414" fill={style?.fill || "#fff"}/></svg>
  );
