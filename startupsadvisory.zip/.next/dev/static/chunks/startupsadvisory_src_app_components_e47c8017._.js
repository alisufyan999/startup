(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BRAND_LOGOS",
    ()=>BRAND_LOGOS
]);
const BRAND_LOGOS = [
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "heroBrand": "LogosSlider-module__ElbhZa__heroBrand",
  "logoItems": "LogosSlider-module__ElbhZa__logoItems",
  "logosSliderSection": "LogosSlider-module__ElbhZa__logosSliderSection",
  "scroll-left": "LogosSlider-module__ElbhZa__scroll-left",
});
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-client] (css module)");
"use client";
;
;
;
;
const LogosSlider = ({ className })=>{
    // Duplicate logos for seamless infinite loop
    const duplicatedLogos = __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"] && __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"].length > 0 ? [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"],
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"]
    ] : [];
    if (duplicatedLogos.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logosSliderSection} ${className} py-4 md:py-6`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroBrand} overflow-hidden whitespace-nowrap relative w-full mx-auto`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoItems} inline-flex`,
                children: duplicatedLogos.map((logo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: logo.src,
                        alt: logo.alt,
                        className: "mx-4",
                        width: 200,
                        height: 100
                    }, `${logo.alt}-${index}`, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                        lineNumber: 23,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                lineNumber: 21,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = LogosSlider;
const __TURBOPACK__default__export__ = LogosSlider;
var _c;
__turbopack_context__.k.register(_c, "LogosSlider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "bottomZero": "HeroBanner-module__HJajBq__bottomZero",
  "content": "HeroBanner-module__HJajBq__content",
  "float": "HeroBanner-module__HJajBq__float",
  "heroBackground": "HeroBanner-module__HJajBq__heroBackground",
});
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/icons/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-client] (css module)");
"use client";
;
;
;
;
;
;
function HeroBanner({ headline, headlineHighlight, subheadline, description, ctaButton, className = "" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroBackground} relative sectionPadding pb-0 overflow-hidden ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "2xl",
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content} relative z-10`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center text-center gap-6 md:gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-5xl lg:text-6xl font-extrabold max-w-3xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-white",
                                    children: headline
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this),
                                headlineHighlight && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: headlineHighlight
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 28,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false),
                                subheadline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white",
                                        children: subheadline
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 33,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-base md:text-lg lg:text-xl text-white/80 max-w-3xl leading-relaxed",
                            children: description
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: ctaButton.href,
                                variant: ctaButton.variant || "secondary",
                                size: "lg",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowRightIcon"], {}, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 45,
                                    columnNumber: 21
                                }, void 0),
                                iconPosition: "right",
                                children: ctaButton.text
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                lineNumber: 41,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "mt-16"
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = HeroBanner;
var _c;
__turbopack_context__.k.register(_c, "HeroBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FAQ
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function FAQ({ faqs, sectionData, className = "" }) {
    _s();
    const [openIndex, setOpenIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const toggleFAQ = (index)=>{
        setOpenIndex(openIndex === index ? null : index);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `relative py-12 sm:py-16 md:py-20 lg:py-24 xl:py-17 ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            maxWidth: "xl",
            className: "px-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center gap-8 sm:gap-10 md:gap-12 lg:gap-14",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center w-full px-4 sm:px-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-3 sm:mb-4 md:mb-5 leading-tight",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white",
                                        children: sectionData.title.part1
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                        lineNumber: 45,
                                        columnNumber: 29
                                    }, this),
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: sectionData.title.part2
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                        lineNumber: 46,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                lineNumber: 44,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm sm:text-base md:text-lg lg:text-xl text-white/80 max-w-2xl mx-auto leading-relaxed px-2",
                                children: sectionData.subtitle
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                lineNumber: 48,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                        lineNumber: 43,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-0",
                            children: faqs.map((faq, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-white/10 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>toggleFAQ(index),
                                            className: "w-full px-0 py-4 sm:py-5 md:py-6 flex items-center justify-between text-left focus:outline-none transition-colors hover:opacity-80 gap-3 sm:gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white font-semibold text-base sm:text-lg md:text-xl lg:text-2xl pr-2 sm:pr-4 flex-1 leading-snug sm:leading-normal",
                                                    children: faq.question
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                                    lineNumber: 65,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white text-xl sm:text-2xl md:text-3xl font-light flex-shrink-0 w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 flex items-center justify-center",
                                                    children: openIndex === index ? "−" : "+"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                                    lineNumber: 68,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                            lineNumber: 61,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `overflow-hidden transition-all duration-300 ${openIndex === index ? "max-h-[500px] pb-4 sm:pb-5 md:pb-6" : "max-h-0"}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white/80 text-sm sm:text-base md:text-lg lg:text-xl leading-relaxed pr-2 sm:pr-4 md:pr-8",
                                                children: faq.answer
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                                lineNumber: 76,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                            lineNumber: 72,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                    lineNumber: 57,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                            lineNumber: 55,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                        lineNumber: 54,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                lineNumber: 41,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
            lineNumber: 40,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
        lineNumber: 37,
        columnNumber: 9
    }, this);
}
_s(FAQ, "6UZ+mnQ9sKC06YXeyhrfGXQCT10=");
_c = FAQ;
var _c;
__turbopack_context__.k.register(_c, "FAQ");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/Contact/Contact.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "accountManagers": "Contact-module__GkYcJa__accountManagers",
  "avatarPlaceholder": "Contact-module__GkYcJa__avatarPlaceholder",
  "client_image": "Contact-module__GkYcJa__client_image",
  "contactCard": "Contact-module__GkYcJa__contactCard",
  "contactForm": "Contact-module__GkYcJa__contactForm",
  "contactSection": "Contact-module__GkYcJa__contactSection",
  "descriptionText": "Contact-module__GkYcJa__descriptionText",
  "formContent": "Contact-module__GkYcJa__formContent",
  "formFieldFull": "Contact-module__GkYcJa__formFieldFull",
  "formHeading": "Contact-module__GkYcJa__formHeading",
  "formRow": "Contact-module__GkYcJa__formRow",
  "globeIcon": "Contact-module__GkYcJa__globeIcon",
  "heading1": "Contact-module__GkYcJa__heading1",
  "heading2": "Contact-module__GkYcJa__heading2",
  "headingWithIcon": "Contact-module__GkYcJa__headingWithIcon",
  "highlightText": "Contact-module__GkYcJa__highlightText",
  "infoContent": "Contact-module__GkYcJa__infoContent",
  "inputField": "Contact-module__GkYcJa__inputField",
  "leftSection": "Contact-module__GkYcJa__leftSection",
  "managerImage": "Contact-module__GkYcJa__managerImage",
  "rightSection": "Contact-module__GkYcJa__rightSection",
  "rocket1": "Contact-module__GkYcJa__rocket1",
  "submitButton": "Contact-module__GkYcJa__submitButton",
  "textareaField": "Contact-module__GkYcJa__textareaField",
});
}),
"[project]/startupsadvisory/src/app/components/Contact/Contact.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Contact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Contact/Contact.module.css [app-client] (css module)");
"use client";
;
;
;
function Contact() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactSection,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "xl",
                className: "px-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactCard,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftSection,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoContent,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headingWithIcon,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].globeIcon,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "24",
                                                    height: "24",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "#0fdac2",
                                                    strokeWidth: "2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "12",
                                                            cy: "12",
                                                            r: "10"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 25,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                            x1: "2",
                                                            y1: "12",
                                                            x2: "22",
                                                            y2: "12"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 26,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 27,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 17,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 16,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heading1,
                                                children: "Fill Up Your Details"
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 30,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 15,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headingWithIcon,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].globeIcon,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "24",
                                                    height: "24",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "#0fdac2",
                                                    strokeWidth: "2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "12",
                                                            cy: "12",
                                                            r: "10"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 44,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                            x1: "2",
                                                            y1: "12",
                                                            x2: "22",
                                                            y2: "12"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 45,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 46,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 36,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 35,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heading2,
                                                children: "One of Our Account Managers Will Contact You Shortly."
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 49,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 34,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/assets/images/contact-client.webp",
                                        className: `img-fluid ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].client_image}`
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 54,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].descriptionText,
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                lineNumber: 13,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                            lineNumber: 12,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rightSection,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formContent,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formHeading,
                                        children: [
                                            "Ready To ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].highlightText,
                                                children: "Connect"
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 73,
                                                columnNumber: 26
                                            }, this),
                                            "?"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 72,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactForm,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formField,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "text",
                                                            placeholder: "Name*",
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                            required: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 81,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 80,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formField,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "email",
                                                            placeholder: "Email*",
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                            required: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 89,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 88,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 79,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formFieldFull,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "tel",
                                                        placeholder: "Phone Number*",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                        required: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 101,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 99,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formFieldFull,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "text",
                                                        placeholder: "Company Name*",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                        required: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 113,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 111,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formFieldFull,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        placeholder: "Message*",
                                                        rows: 5,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textareaField,
                                                        required: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 125,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 124,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 123,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "submit",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submitButton,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Submit"
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 136,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        width: "20",
                                                        height: "20",
                                                        viewBox: "0 0 24 24",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        strokeWidth: "2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                                x1: "5",
                                                                y1: "12",
                                                                x2: "19",
                                                                y2: "12"
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                                lineNumber: 145,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                                                points: "12 5 19 12 12 19"
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                                lineNumber: 146,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 137,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 135,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 77,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                    lineNumber: 10,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: "/assets/images/rocket1.webp",
                className: `img-fluid ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rocket1}`
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = Contact;
var _c;
__turbopack_context__.k.register(_c, "Contact");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/Reviews/Reviews.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "avatar": "Reviews-module__smzEVW__avatar",
  "badge": "Reviews-module__smzEVW__badge",
  "badgeLogo": "Reviews-module__smzEVW__badgeLogo",
  "badgeRating": "Reviews-module__smzEVW__badgeRating",
  "badgesContainer": "Reviews-module__smzEVW__badgesContainer",
  "ctaText": "Reviews-module__smzEVW__ctaText",
  "facebookLogo": "Reviews-module__smzEVW__facebookLogo",
  "googleLogo": "Reviews-module__smzEVW__googleLogo",
  "header": "Reviews-module__smzEVW__header",
  "heading": "Reviews-module__smzEVW__heading",
  "highlightedCard": "Reviews-module__smzEVW__highlightedCard",
  "reviewCard": "Reviews-module__smzEVW__reviewCard",
  "reviewCardContent": "Reviews-module__smzEVW__reviewCardContent",
  "reviewHeader": "Reviews-module__smzEVW__reviewHeader",
  "reviewSource": "Reviews-module__smzEVW__reviewSource",
  "reviewText": "Reviews-module__smzEVW__reviewText",
  "reviewerInfo": "Reviews-module__smzEVW__reviewerInfo",
  "reviewerName": "Reviews-module__smzEVW__reviewerName",
  "reviewsMasonry": "Reviews-module__smzEVW__reviewsMasonry",
  "rocketIcon": "Reviews-module__smzEVW__rocketIcon",
  "section": "Reviews-module__smzEVW__section",
  "starRating": "Reviews-module__smzEVW__starRating",
  "subtitle": "Reviews-module__smzEVW__subtitle",
  "subtitleContainer": "Reviews-module__smzEVW__subtitleContainer",
  "trustpilotLogo": "Reviews-module__smzEVW__trustpilotLogo",
  "videoContainer": "Reviews-module__smzEVW__videoContainer",
  "videoElement": "Reviews-module__smzEVW__videoElement",
});
}),
"[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Reviews
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Reviews/Reviews.module.css [app-client] (css module)");
"use client";
;
;
;
;
function Reviews() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heading,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white",
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REVIEWS_SECTION"].heading.part1
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                        lineNumber: 16,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REVIEWS_SECTION"].heading.part2
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                        lineNumber: 19,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                lineNumber: 15,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitleContainer,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REVIEWS_SECTION"].subtitle
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                    lineNumber: 24,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                lineNumber: 23,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].ctaText,
                                children: [
                                    "See how",
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: "Smart Marketing AI Teams"
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                        lineNumber: 28,
                                        columnNumber: 15
                                    }, this),
                                    " ",
                                    "turned invisibility into daily inquiries"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                lineNumber: 26,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                        lineNumber: 14,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badgesContainer,
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REVIEWS_SECTION"].ratingBadges.map((badge, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badge,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badgeLogo,
                                        children: [
                                            badge.platform === "Trustpilot" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: "/assets/images/trust-pilot.webp",
                                                alt: "Google Logo",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trustpilotLogo
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                lineNumber: 42,
                                                columnNumber: 21
                                            }, this),
                                            badge.platform === "Google" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: "/assets/images/google.webp",
                                                alt: "Google Logo",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].googleLogo
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                lineNumber: 45,
                                                columnNumber: 20
                                            }, this),
                                            badge.platform === "Facebook" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: "/assets/images/facebook.webp",
                                                alt: "Facebook Logo",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].facebookLogo
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                lineNumber: 48,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                        lineNumber: 40,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badgeRating,
                                        children: [
                                            "Rated ",
                                            badge.rating
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                        lineNumber: 51,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                lineNumber: 36,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewsMasonry,
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REVIEWS_SECTION"].reviews.map((review, index)=>{
                            // Card 3 (index 2) and Card 6 (index 5) should have borders
                            const hasBorder = index === 2 || index === 5;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewCard} ${hasBorder ? __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].highlightedCard : ""}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewCardContent,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewHeader,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].avatar,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: review.initials
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                        lineNumber: 74,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                    lineNumber: 73,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewerInfo,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewerName,
                                                            children: review.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                            lineNumber: 77,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewSource,
                                                            children: [
                                                                review.source,
                                                                " - ",
                                                                review.date
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                            lineNumber: 78,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                    lineNumber: 76,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].starRating,
                                                    children: [
                                                        ...Array(5)
                                                    ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            width: "16",
                                                            height: "16",
                                                            viewBox: "0 0 24 24",
                                                            fill: "#0fdac2",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                                lineNumber: 92,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, i, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                            lineNumber: 85,
                                                            columnNumber: 23
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                    lineNumber: 83,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                            lineNumber: 72,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].reviewText,
                                            children: review.text
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                            lineNumber: 99,
                                            columnNumber: 17
                                        }, this),
                                        review.isVideo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoContainer,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                                                src: "/assets/images/videoplayback.mp4",
                                                controls: true,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Reviews$2f$Reviews$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoElement,
                                                children: "Your browser does not support the video tag."
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                                lineNumber: 104,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                            lineNumber: 103,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                    lineNumber: 70,
                                    columnNumber: 17
                                }, this)
                            }, review.id, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                                lineNumber: 64,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                        lineNumber: 59,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
                lineNumber: 12,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/Reviews/Reviews.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_c = Reviews;
var _c;
__turbopack_context__.k.register(_c, "Reviews");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "closeButton": "VideoPopup-module__JCSAFG__closeButton",
  "fadeIn": "VideoPopup-module__JCSAFG__fadeIn",
  "popupContent": "VideoPopup-module__JCSAFG__popupContent",
  "popupOverlay": "VideoPopup-module__JCSAFG__popupOverlay",
  "sizeLg": "VideoPopup-module__JCSAFG__sizeLg",
  "sizeMd": "VideoPopup-module__JCSAFG__sizeMd",
  "sizeSm": "VideoPopup-module__JCSAFG__sizeSm",
  "sizeXl": "VideoPopup-module__JCSAFG__sizeXl",
  "sizeXxl": "VideoPopup-module__JCSAFG__sizeXxl",
  "videoContainer": "VideoPopup-module__JCSAFG__videoContainer",
  "videoElement": "VideoPopup-module__JCSAFG__videoElement",
  "videoIframe": "VideoPopup-module__JCSAFG__videoIframe",
});
}),
"[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const VideoPopup = ({ isOpen, onClose, videoUrl, videoTitle = "Video player", size = "lg" })=>{
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPopup.useEffect": ()=>{
            if (isOpen) {
                document.body.style.overflow = "hidden";
            } else {
                document.body.style.overflow = "unset";
            }
            return ({
                "VideoPopup.useEffect": ()=>{
                    document.body.style.overflow = "unset";
                }
            })["VideoPopup.useEffect"];
        }
    }["VideoPopup.useEffect"], [
        isOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPopup.useEffect": ()=>{
            const handleEscape = {
                "VideoPopup.useEffect.handleEscape": (e)=>{
                    if (e.key === "Escape") {
                        onClose();
                    }
                }
            }["VideoPopup.useEffect.handleEscape"];
            if (isOpen) {
                window.addEventListener("keydown", handleEscape);
            }
            return ({
                "VideoPopup.useEffect": ()=>{
                    window.removeEventListener("keydown", handleEscape);
                }
            })["VideoPopup.useEffect"];
        }
    }["VideoPopup.useEffect"], [
        isOpen,
        onClose
    ]);
    if (!isOpen) return null;
    // Check if videoUrl is a local video file
    const isLocalVideo = videoUrl && (videoUrl.endsWith('.mp4') || videoUrl.endsWith('.webm') || videoUrl.endsWith('.ogg') || videoUrl.endsWith('.mov'));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].popupOverlay} ${isOpen ? __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fadeIn : ""}`,
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].popupContent} ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][`size${size === "sm" ? "Sm" : size === "md" ? "Md" : size === "lg" ? "Lg" : size === "xl" ? "Xl" : "Xxl"}`]}`,
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClose,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeButton,
                    "aria-label": "Close video",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "w-6 h-6",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M6 18L18 6M6 6l12 12"
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                            lineNumber: 82,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                    lineNumber: 71,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoContainer,
                    children: isLocalVideo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                        src: videoUrl,
                        controls: true,
                        autoPlay: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoElement,
                        children: "Your browser does not support the video tag."
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                        lineNumber: 94,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                        src: videoUrl || "https://www.youtube.com/embed/dQw4w9WgXcQ",
                        title: videoTitle,
                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                        allowFullScreen: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoIframe
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                        lineNumber: 103,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
            lineNumber: 66,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(VideoPopup, "3ubReDTFssvu4DHeldAg55cW/CI=");
_c = VideoPopup;
const __TURBOPACK__default__export__ = VideoPopup;
var _c;
__turbopack_context__.k.register(_c, "VideoPopup");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "backgroundDecoration": "ProfessionalOnline-module__4_2b0a__backgroundDecoration",
  "barBackground": "ProfessionalOnline-module__4_2b0a__barBackground",
  "barFill": "ProfessionalOnline-module__4_2b0a__barFill",
  "barFillPurple": "ProfessionalOnline-module__4_2b0a__barFillPurple",
  "barFillTeal": "ProfessionalOnline-module__4_2b0a__barFillTeal",
  "barLabel": "ProfessionalOnline-module__4_2b0a__barLabel",
  "barWrapper": "ProfessionalOnline-module__4_2b0a__barWrapper",
  "barsContainer": "ProfessionalOnline-module__4_2b0a__barsContainer",
  "bottomHeading": "ProfessionalOnline-module__4_2b0a__bottomHeading",
  "bottomHeadingPart1": "ProfessionalOnline-module__4_2b0a__bottomHeadingPart1",
  "bottomHeadingPart2": "ProfessionalOnline-module__4_2b0a__bottomHeadingPart2",
  "bottomHeadingPart3": "ProfessionalOnline-module__4_2b0a__bottomHeadingPart3",
  "contentWrapper": "ProfessionalOnline-module__4_2b0a__contentWrapper",
  "description": "ProfessionalOnline-module__4_2b0a__description",
  "heading": "ProfessionalOnline-module__4_2b0a__heading",
  "headingPart1": "ProfessionalOnline-module__4_2b0a__headingPart1",
  "headingPart2": "ProfessionalOnline-module__4_2b0a__headingPart2",
  "headingPart3": "ProfessionalOnline-module__4_2b0a__headingPart3",
  "leftSection": "ProfessionalOnline-module__4_2b0a__leftSection",
  "overlayText": "ProfessionalOnline-module__4_2b0a__overlayText",
  "overlayTextContainer": "ProfessionalOnline-module__4_2b0a__overlayTextContainer",
  "personImage": "ProfessionalOnline-module__4_2b0a__personImage",
  "personImageContainer": "ProfessionalOnline-module__4_2b0a__personImageContainer",
  "personImageOverlay": "ProfessionalOnline-module__4_2b0a__personImageOverlay",
  "playButton": "ProfessionalOnline-module__4_2b0a__playButton",
  "playButtonContainer": "ProfessionalOnline-module__4_2b0a__playButtonContainer",
  "playIcon": "ProfessionalOnline-module__4_2b0a__playIcon",
  "rightSection": "ProfessionalOnline-module__4_2b0a__rightSection",
  "section": "ProfessionalOnline-module__4_2b0a__section",
  "videoCard": "ProfessionalOnline-module__4_2b0a__videoCard",
  "videoThumbnail": "ProfessionalOnline-module__4_2b0a__videoThumbnail",
  "videoWrapper": "ProfessionalOnline-module__4_2b0a__videoWrapper",
});
}),
"[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const ProfessionalOnline = ()=>{
    _s();
    const [isPopupOpen, setIsPopupOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        maxWidth: "xl",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contentWrapper,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftSection,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heading,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headingPart1,
                                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].heading.part1
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 22,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headingPart2,
                                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].heading.part2
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 25,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headingPart3,
                                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].heading.part3
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 28,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 21,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].description,
                                            children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].description
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 32,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].barsContainer,
                                            children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].contentBars.map((bar, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].barWrapper,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].barLabel,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    bar.label,
                                                                    " :"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 41,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 40,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].barBackground,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].barFill} ${bar.color === "purple" ? __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].barFillPurple : __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].barFillTeal}`,
                                                                style: {
                                                                    width: `${bar.progress}%`
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 44,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 43,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, index, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 39,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 37,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                    lineNumber: 20,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rightSection,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoWrapper,
                                            onClick: ()=>setIsPopupOpen(true),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoCard,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoThumbnail,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].personImageContainer,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].video.thumbnail,
                                                                        alt: "Person",
                                                                        fill: true,
                                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].personImage} ms-4 max-w-[10rem]`,
                                                                        priority: true
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                        lineNumber: 70,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].personImageOverlay
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                        lineNumber: 77,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 69,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].overlayTextContainer,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].overlayText,
                                                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].video.overlayText
                                                                }, void 0, false, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                    lineNumber: 82,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 81,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                        lineNumber: 67,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].playButtonContainer,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].playButton,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].playIcon,
                                                                fill: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M8 5v14l11-7z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                    lineNumber: 96,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 91,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 90,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                        lineNumber: 89,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                lineNumber: 65,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 60,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].bottomHeading,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].bottomHeadingPart1,
                                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].bottomHeading.part1
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 105,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].bottomHeadingPart2,
                                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].bottomHeading.part2
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 108,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].bottomHeadingPart3,
                                                    children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].bottomHeading.part3
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 111,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 104,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                    lineNumber: 59,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                        lineNumber: 17,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backgroundDecoration
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isPopupOpen,
                onClose: ()=>setIsPopupOpen(false),
                videoUrl: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].video.videoUrl,
                videoTitle: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFESSIONAL_ONLINE"].video.videoTitle,
                size: "lg"
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                lineNumber: 124,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(ProfessionalOnline, "vFErrUU1qYQoaBmFpaEBY5pk8jE=");
_c = ProfessionalOnline;
const __TURBOPACK__default__export__ = ProfessionalOnline;
var _c;
__turbopack_context__.k.register(_c, "ProfessionalOnline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=startupsadvisory_src_app_components_e47c8017._.js.map