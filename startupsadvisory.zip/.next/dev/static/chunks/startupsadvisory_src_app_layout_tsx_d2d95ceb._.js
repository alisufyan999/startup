(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__dcf9cc04._.css",
  "static/chunks/3325b_next_e5efc01d._.js",
  "static/chunks/startupsadvisory_src_app_3d96bf38._.js"
],
    source: "dynamic"
});
