(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/startupsadvisory_src_app_components_611d5aff._.js",
  "static/chunks/startupsadvisory_src_app_components_3aac27a9._.css"
],
    source: "dynamic"
});
