(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/startupsadvisory_src_app_components_f9c53612._.js",
  "static/chunks/startupsadvisory_src_app_components_05f2e351._.css"
],
    source: "dynamic"
});
