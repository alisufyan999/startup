(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/startupsadvisory_src_app_components_fd2a97c6._.js",
  "static/chunks/3325b_react-calendly_dist_index_es_b17ae55b.js",
  "static/chunks/startupsadvisory_src_app_components_987a5564._.css"
],
    source: "dynamic"
});
