(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BRAND_LOGOS",
    ()=>BRAND_LOGOS
]);
const BRAND_LOGOS = [
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "heroBrand": "LogosSlider-module__ElbhZa__heroBrand",
  "logoItems": "LogosSlider-module__ElbhZa__logoItems",
  "logosSliderSection": "LogosSlider-module__ElbhZa__logosSliderSection",
  "scroll-left": "LogosSlider-module__ElbhZa__scroll-left",
});
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-client] (css module)");
"use client";
;
;
;
;
const LogosSlider = ({ className })=>{
    // Duplicate logos for seamless infinite loop
    const duplicatedLogos = __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"] && __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"].length > 0 ? [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"],
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"]
    ] : [];
    if (duplicatedLogos.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logosSliderSection} ${className} py-4 md:py-6`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroBrand} overflow-hidden whitespace-nowrap relative w-full mx-auto`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoItems} inline-flex`,
                children: duplicatedLogos.map((logo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: logo.src,
                        alt: logo.alt,
                        className: "mx-4",
                        width: 200,
                        height: 100
                    }, `${logo.alt}-${index}`, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                        lineNumber: 23,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                lineNumber: 21,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = LogosSlider;
const __TURBOPACK__default__export__ = LogosSlider;
var _c;
__turbopack_context__.k.register(_c, "LogosSlider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "content": "HeroBanner-module__HJajBq__content",
  "float": "HeroBanner-module__HJajBq__float",
  "heroBackground": "HeroBanner-module__HJajBq__heroBackground",
});
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/icons/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-client] (css module)");
"use client";
;
;
;
;
;
;
function HeroBanner({ headline, headlineHighlight, subheadline, description, ctaButton, className = "" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroBackground} relative sectionPadding overflow-hidden ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "2xl",
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content} relative z-10`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center text-center gap-6 md:gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-5xl lg:text-6xl font-extrabold max-w-3xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-white",
                                    children: headline
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 27,
                                    columnNumber: 13
                                }, this),
                                headlineHighlight && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: headlineHighlight
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 30,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false),
                                subheadline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white",
                                        children: subheadline
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 35,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-base md:text-lg lg:text-xl text-white/80 max-w-3xl leading-relaxed",
                            children: description
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: ctaButton.href,
                                variant: ctaButton.variant || "secondary",
                                size: "lg",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowRightIcon"], {}, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 51,
                                    columnNumber: 21
                                }, void 0),
                                iconPosition: "right",
                                children: ctaButton.text
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                lineNumber: 47,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "mt-16"
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = HeroBanner;
var _c;
__turbopack_context__.k.register(_c, "HeroBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FAQ
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function FAQ({ faqs, sectionData, className = "" }) {
    _s();
    const [openIndex, setOpenIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const toggleFAQ = (index)=>{
        setOpenIndex(openIndex === index ? null : index);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `relative py-12 sm:py-16 md:py-20 lg:py-24 xl:py-32 ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            maxWidth: "xl",
            className: "px-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center gap-8 sm:gap-10 md:gap-12 lg:gap-14",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center w-full px-4 sm:px-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-3 sm:mb-4 md:mb-5 leading-tight",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white",
                                        children: sectionData.title.part1
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                        lineNumber: 45,
                                        columnNumber: 29
                                    }, this),
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: sectionData.title.part2
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                        lineNumber: 46,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                lineNumber: 44,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm sm:text-base md:text-lg lg:text-xl text-white/80 max-w-2xl mx-auto leading-relaxed px-2",
                                children: sectionData.subtitle
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                lineNumber: 48,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                        lineNumber: 43,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-0",
                            children: faqs.map((faq, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-white/10 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>toggleFAQ(index),
                                            className: "w-full px-0 py-4 sm:py-5 md:py-6 flex items-center justify-between text-left focus:outline-none transition-colors hover:opacity-80 gap-3 sm:gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white font-semibold text-base sm:text-lg md:text-xl lg:text-2xl pr-2 sm:pr-4 flex-1 leading-snug sm:leading-normal",
                                                    children: faq.question
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                                    lineNumber: 65,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white text-xl sm:text-2xl md:text-3xl font-light flex-shrink-0 w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 flex items-center justify-center",
                                                    children: openIndex === index ? "−" : "+"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                                    lineNumber: 68,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                            lineNumber: 61,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `overflow-hidden transition-all duration-300 ${openIndex === index ? "max-h-[500px] pb-4 sm:pb-5 md:pb-6" : "max-h-0"}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-white/80 text-sm sm:text-base md:text-lg lg:text-xl leading-relaxed pr-2 sm:pr-4 md:pr-8",
                                                children: faq.answer
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                                lineNumber: 76,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                            lineNumber: 72,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                                    lineNumber: 57,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                            lineNumber: 55,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                        lineNumber: 54,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
                lineNumber: 41,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
            lineNumber: 40,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/FAQ/FAQ.tsx",
        lineNumber: 37,
        columnNumber: 9
    }, this);
}
_s(FAQ, "6UZ+mnQ9sKC06YXeyhrfGXQCT10=");
_c = FAQ;
var _c;
__turbopack_context__.k.register(_c, "FAQ");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/Contact/Contact.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "accountManagers": "Contact-module__GkYcJa__accountManagers",
  "avatarPlaceholder": "Contact-module__GkYcJa__avatarPlaceholder",
  "client_image": "Contact-module__GkYcJa__client_image",
  "contactCard": "Contact-module__GkYcJa__contactCard",
  "contactForm": "Contact-module__GkYcJa__contactForm",
  "contactSection": "Contact-module__GkYcJa__contactSection",
  "descriptionText": "Contact-module__GkYcJa__descriptionText",
  "formContent": "Contact-module__GkYcJa__formContent",
  "formFieldFull": "Contact-module__GkYcJa__formFieldFull",
  "formHeading": "Contact-module__GkYcJa__formHeading",
  "formRow": "Contact-module__GkYcJa__formRow",
  "globeIcon": "Contact-module__GkYcJa__globeIcon",
  "heading1": "Contact-module__GkYcJa__heading1",
  "heading2": "Contact-module__GkYcJa__heading2",
  "headingWithIcon": "Contact-module__GkYcJa__headingWithIcon",
  "highlightText": "Contact-module__GkYcJa__highlightText",
  "infoContent": "Contact-module__GkYcJa__infoContent",
  "inputField": "Contact-module__GkYcJa__inputField",
  "leftSection": "Contact-module__GkYcJa__leftSection",
  "managerImage": "Contact-module__GkYcJa__managerImage",
  "rightSection": "Contact-module__GkYcJa__rightSection",
  "rocket1": "Contact-module__GkYcJa__rocket1",
  "submitButton": "Contact-module__GkYcJa__submitButton",
  "textareaField": "Contact-module__GkYcJa__textareaField",
});
}),
"[project]/startupsadvisory/src/app/components/Contact/Contact.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Contact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Contact/Contact.module.css [app-client] (css module)");
"use client";
;
;
;
function Contact() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactSection,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "xl",
                className: "px-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactCard,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftSection,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoContent,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headingWithIcon,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].globeIcon,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "24",
                                                    height: "24",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "#0fdac2",
                                                    strokeWidth: "2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "12",
                                                            cy: "12",
                                                            r: "10"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 25,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                            x1: "2",
                                                            y1: "12",
                                                            x2: "22",
                                                            y2: "12"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 26,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 27,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 17,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 16,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heading1,
                                                children: "Fill Up Your Details"
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 30,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 15,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headingWithIcon,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].globeIcon,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "24",
                                                    height: "24",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "#0fdac2",
                                                    strokeWidth: "2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "12",
                                                            cy: "12",
                                                            r: "10"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 44,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                            x1: "2",
                                                            y1: "12",
                                                            x2: "22",
                                                            y2: "12"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 45,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 46,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 36,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 35,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heading2,
                                                children: "One of Our Account Managers Will Contact You Shortly."
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 49,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 34,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/assets/images/contact-client.webp",
                                        className: `img-fluid ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].client_image}`
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 54,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].descriptionText,
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                lineNumber: 13,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                            lineNumber: 12,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rightSection,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formContent,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formHeading,
                                        children: [
                                            "Ready To ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].highlightText,
                                                children: "Connect"
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 73,
                                                columnNumber: 26
                                            }, this),
                                            "?"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 72,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactForm,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formField,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "text",
                                                            placeholder: "Name*",
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                            required: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 81,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 80,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formField,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "email",
                                                            placeholder: "Email*",
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                            required: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                            lineNumber: 89,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 88,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 79,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formFieldFull,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "tel",
                                                        placeholder: "Phone Number*",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                        required: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 101,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 99,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formFieldFull,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "text",
                                                        placeholder: "Company Name*",
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inputField,
                                                        required: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 113,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 111,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formRow,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formFieldFull,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        placeholder: "Message*",
                                                        rows: 5,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textareaField,
                                                        required: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 125,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                    lineNumber: 124,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 123,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "submit",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submitButton,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Submit"
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 136,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        width: "20",
                                                        height: "20",
                                                        viewBox: "0 0 24 24",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        strokeWidth: "2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                                x1: "5",
                                                                y1: "12",
                                                                x2: "19",
                                                                y2: "12"
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                                lineNumber: 145,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                                                points: "12 5 19 12 12 19"
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                                lineNumber: 146,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                        lineNumber: 137,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                                lineNumber: 135,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                        lineNumber: 77,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                    lineNumber: 10,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: "/assets/images/rocket1.webp",
                className: `img-fluid ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Contact$2f$Contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rocket1}`
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
                lineNumber: 154,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/Contact/Contact.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = Contact;
var _c;
__turbopack_context__.k.register(_c, "Contact");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "closeButton": "VideoPopup-module__JCSAFG__closeButton",
  "fadeIn": "VideoPopup-module__JCSAFG__fadeIn",
  "popupContent": "VideoPopup-module__JCSAFG__popupContent",
  "popupOverlay": "VideoPopup-module__JCSAFG__popupOverlay",
  "sizeLg": "VideoPopup-module__JCSAFG__sizeLg",
  "sizeMd": "VideoPopup-module__JCSAFG__sizeMd",
  "sizeSm": "VideoPopup-module__JCSAFG__sizeSm",
  "sizeXl": "VideoPopup-module__JCSAFG__sizeXl",
  "sizeXxl": "VideoPopup-module__JCSAFG__sizeXxl",
  "videoContainer": "VideoPopup-module__JCSAFG__videoContainer",
  "videoIframe": "VideoPopup-module__JCSAFG__videoIframe",
});
}),
"[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const VideoPopup = ({ isOpen, onClose, videoUrl, videoTitle = "Video player", size = "lg" })=>{
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPopup.useEffect": ()=>{
            if (isOpen) {
                document.body.style.overflow = "hidden";
            } else {
                document.body.style.overflow = "unset";
            }
            return ({
                "VideoPopup.useEffect": ()=>{
                    document.body.style.overflow = "unset";
                }
            })["VideoPopup.useEffect"];
        }
    }["VideoPopup.useEffect"], [
        isOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPopup.useEffect": ()=>{
            const handleEscape = {
                "VideoPopup.useEffect.handleEscape": (e)=>{
                    if (e.key === "Escape") {
                        onClose();
                    }
                }
            }["VideoPopup.useEffect.handleEscape"];
            if (isOpen) {
                window.addEventListener("keydown", handleEscape);
            }
            return ({
                "VideoPopup.useEffect": ()=>{
                    window.removeEventListener("keydown", handleEscape);
                }
            })["VideoPopup.useEffect"];
        }
    }["VideoPopup.useEffect"], [
        isOpen,
        onClose
    ]);
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].popupOverlay} ${isOpen ? __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fadeIn : ""}`,
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].popupContent} ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][`size${size === "sm" ? "Sm" : size === "md" ? "Md" : size === "lg" ? "Lg" : size === "xl" ? "Xl" : "Xxl"}`]}`,
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClose,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeButton,
                    "aria-label": "Close video",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "w-6 h-6",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M6 18L18 6M6 6l12 12"
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                            lineNumber: 74,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoContainer,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                        src: videoUrl || "https://www.youtube.com/embed/dQw4w9WgXcQ",
                        title: videoTitle,
                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                        allowFullScreen: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoIframe
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                        lineNumber: 85,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
            lineNumber: 58,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(VideoPopup, "3ubReDTFssvu4DHeldAg55cW/CI=");
_c = VideoPopup;
const __TURBOPACK__default__export__ = VideoPopup;
var _c;
__turbopack_context__.k.register(_c, "VideoPopup");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "backgroundDecoration": "ProfessionalOnline-module__4_2b0a__backgroundDecoration",
  "videoCard": "ProfessionalOnline-module__4_2b0a__videoCard",
});
}),
"[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const ProfessionalOnline = ()=>{
    _s();
    const [isPopupOpen, setIsPopupOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const contentBars = [
        {
            label: "Content",
            progress: 85,
            color: "purple"
        },
        {
            label: "Content",
            progress: 70,
            color: "teal"
        },
        {
            label: "Content",
            progress: 90,
            color: "purple"
        },
        {
            label: "Content",
            progress: 65,
            color: "teal"
        },
        {
            label: "Content",
            progress: 80,
            color: "purple"
        },
        {
            label: "Content",
            progress: 75,
            color: "teal"
        },
        {
            label: "Content",
            progress: 88,
            color: "purple"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-16 md:py-24 relative overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        maxWidth: "xl",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative z-10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "Local "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 30,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-[#0fdac2]",
                                                    children: "Businesses "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 31,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "Struggle to Stay Visible"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 32,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 29,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-white/80 text-lg md:text-xl mb-8 leading-relaxed",
                                            children: "You're great at what you do, but your marketing falls behind. Agencies cost a fortune. Freelancers disappear."
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 34,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: contentBars.map((bar, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-white/70 text-sm font-medium",
                                                                children: [
                                                                    bar.label,
                                                                    " :"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 44,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 43,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-full h-3 bg-[#1a1a2e] rounded-full overflow-hidden",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: `h-full rounded-full transition-all duration-1000 ${bar.color === "purple" ? "bg-[#643bff]" : "bg-[#0fdac2]"}`,
                                                                style: {
                                                                    width: `${bar.progress}%`
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 49,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 48,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, index, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 42,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 40,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                    lineNumber: 28,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative z-10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative group cursor-pointer",
                                            onClick: ()=>setIsPopupOpen(true),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoCard} relative rounded-2xl overflow-hidden transition-all duration-300 group-hover:shadow-[#643bff]/60`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "aspect-video bg-gradient-to-br from-[#1a1a2e] to-[#0a0a1a] flex items-center relative overflow-hidden",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "absolute left-0 top-0 bottom-0 w-[12rem] md:w-[14rem] lg:w-[16rem]",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: "/assets/images/person-img.webp",
                                                                        alt: "Person",
                                                                        fill: true,
                                                                        className: "object-cover object-center",
                                                                        priority: true,
                                                                        sizes: "(max-width: 768px) 12rem, (max-width: 1024px) 14rem, 16rem"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                        lineNumber: 72,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute inset-0 bg-gradient-to-r from-[#020016]/60 to-transparent"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                        lineNumber: 80,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 71,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "absolute right-0 top-0 bottom-0 left-[12rem] md:left-[14rem] lg:left-[16rem] flex items-center px-4 md:px-6 lg:px-8",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-white/90 text-xs md:text-sm lg:text-base font-medium leading-relaxed drop-shadow-lg",
                                                                    children: "Your Smart Marketing AI Team op de e a behind -the-scenes planning promotions, creating visuals."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                    lineNumber: 85,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 84,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                        lineNumber: 69,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "absolute inset-0 flex items-center justify-center pointer-events-none",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-20 h-20 md:w-24 md:h-24 bg-[#643bff] rounded-full flex items-center justify-center shadow-lg shadow-[#643bff]/50 transition-all duration-300 group-hover:scale-110 group-hover:shadow-[#643bff]/70 z-10 pointer-events-auto",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-10 h-10 md:w-12 md:h-12 text-white ml-1",
                                                                fill: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M8 5v14l11-7z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                    lineNumber: 99,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 94,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 93,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                        lineNumber: 92,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                lineNumber: 67,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-3xl md:text-4xl lg:text-5xl font-extrabold mt-8 text-center lg:text-left leading-tight",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "The Simple Way to Look "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 108,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-[#0fdac2]",
                                                    children: "Professional "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 109,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "Online"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 110,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 107,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                    lineNumber: 64,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backgroundDecoration
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isPopupOpen,
                onClose: ()=>setIsPopupOpen(false),
                videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                videoTitle: "Professional Online Video",
                size: "lg"
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                lineNumber: 121,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(ProfessionalOnline, "vFErrUU1qYQoaBmFpaEBY5pk8jE=");
_c = ProfessionalOnline;
const __TURBOPACK__default__export__ = ProfessionalOnline;
var _c;
__turbopack_context__.k.register(_c, "ProfessionalOnline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "ctaBanner": "CTABanner-module__fAmPGa__ctaBanner",
});
}),
"[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/icons/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$CTABanner$2f$CTABanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.module.css [app-client] (css module)");
"use client";
;
;
;
;
;
const CTABanner = ({ question = "What's Your", questionHighlight = "Challenge", buttonText = "Let's Get Your Marketing Handled", buttonHref = "/get-started", backgroundImage = "/assets/images/cta-banner.webp", className = "" })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$CTABanner$2f$CTABanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].ctaBanner} ${className} relative overflow-hidden`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            maxWidth: "xl",
            className: "relative z-10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row items-center justify-between gap-6 md:gap-8 py-12 md:py-16",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-extrabold text-center md:text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-white",
                                    children: [
                                        question,
                                        " "
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                                    lineNumber: 34,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[#0fdac2]",
                                    children: questionHighlight
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                                    lineNumber: 35,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-white",
                                    children: "?"
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                                    lineNumber: 36,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                            lineNumber: 33,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                        lineNumber: 32,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-shrink-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: buttonHref,
                            variant: "secondary",
                            size: "lg",
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowRightIcon"], {
                                style: {
                                    fill: "#fff"
                                }
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                                lineNumber: 46,
                                columnNumber: 21
                            }, void 0),
                            iconPosition: "right",
                            className: "whitespace-nowrap",
                            children: buttonText
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                            lineNumber: 42,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
                lineNumber: 30,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
            lineNumber: 29,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/CTABanner/CTABanner.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = CTABanner;
const __TURBOPACK__default__export__ = CTABanner;
var _c;
__turbopack_context__.k.register(_c, "CTABanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/stores/useModalStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useModalStore",
    ()=>useModalStore
]);
(()=>{
    const e = new Error("Cannot find module 'zustand'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
const useModalStore = create((set)=>({
        isOpen: false,
        openModal: ()=>set({
                isOpen: true
            }),
        closeModal: ()=>set({
                isOpen: false
            })
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/EmpoweredTeam/empoweredTeamData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EMPOWERED_TEAM_DATA",
    ()=>EMPOWERED_TEAM_DATA
]);
const EMPOWERED_TEAM_DATA = [
    {
        id: "creative-design",
        name: "Creative & Design",
        members: [
            {
                id: "brand-designer",
                title: "Brand Designer",
                subtitle: "Builds The Foundation of Your Brand",
                skills: [
                    "Logo Design",
                    "Brand Guidelines",
                    "Color Palette",
                    "Typography System",
                    "Social Templates",
                    "Rebrand Plan",
                    "Business Cards",
                    "Email Signature",
                    "Icon Set",
                    "Mockups",
                    "Packaging",
                    "Stationery",
                    "Uniform Branding"
                ],
                buttonText: "Hire Brand Designer",
                toolIcons: [
                    {
                        name: "Ai",
                        label: "AI",
                        bgColor: "bg-orange-500"
                    },
                    {
                        name: "F",
                        label: "Figma",
                        bgColor: "bg-[#0fdac2]"
                    },
                    {
                        name: "Ps",
                        label: "Photoshop",
                        bgColor: "bg-blue-600"
                    }
                ]
            },
            {
                id: "ui-ux-designer",
                title: "UI/UX Designer",
                subtitle: "Creates Intuitive User Experiences",
                skills: [
                    "Wireframing",
                    "Prototyping",
                    "User Research",
                    "Design Systems",
                    "Mobile Design",
                    "Web Design",
                    "User Testing",
                    "Accessibility"
                ],
                buttonText: "Hire UI/UX Designer",
                toolIcons: [
                    {
                        name: "F",
                        label: "Figma",
                        bgColor: "bg-[#0fdac2]"
                    },
                    {
                        name: "Xd",
                        label: "XD",
                        bgColor: "bg-purple-500"
                    },
                    {
                        name: "Sk",
                        label: "Sketch",
                        bgColor: "bg-yellow-500"
                    }
                ]
            },
            {
                id: "graphic-designer",
                title: "Graphic Designer",
                subtitle: "Brings Visual Concepts to Life",
                skills: [
                    "Print Design",
                    "Digital Graphics",
                    "Illustration",
                    "Photo Editing",
                    "Banner Design",
                    "Infographics",
                    "Poster Design",
                    "Brochures"
                ],
                buttonText: "Hire Graphic Designer",
                toolIcons: [
                    {
                        name: "Ai",
                        label: "AI",
                        bgColor: "bg-orange-500"
                    },
                    {
                        name: "Ps",
                        label: "Photoshop",
                        bgColor: "bg-blue-600"
                    },
                    {
                        name: "Id",
                        label: "InDesign",
                        bgColor: "bg-pink-500"
                    }
                ]
            }
        ]
    },
    {
        id: "marketing-growth",
        name: "Marketing & Growth",
        members: [
            {
                id: "content-marketer",
                title: "Content Marketer",
                subtitle: "Crafts Stories That Convert",
                skills: [
                    "Blog Writing",
                    "SEO Content",
                    "Social Media Posts",
                    "Email Campaigns",
                    "Case Studies",
                    "White Papers",
                    "Content Strategy",
                    "Copywriting"
                ],
                buttonText: "Hire Content Marketer",
                toolIcons: [
                    {
                        name: "Ai",
                        label: "AI",
                        bgColor: "bg-orange-500"
                    },
                    {
                        name: "G",
                        label: "Google",
                        bgColor: "bg-blue-500"
                    },
                    {
                        name: "H",
                        label: "HubSpot",
                        bgColor: "bg-orange-400"
                    }
                ]
            },
            {
                id: "seo-specialist",
                title: "SEO Specialist",
                subtitle: "Drives Organic Traffic Growth",
                skills: [
                    "Keyword Research",
                    "On-Page SEO",
                    "Link Building",
                    "Technical SEO",
                    "Local SEO",
                    "Analytics",
                    "Content Optimization",
                    "Rank Tracking"
                ],
                buttonText: "Hire SEO Specialist",
                toolIcons: [
                    {
                        name: "G",
                        label: "Google",
                        bgColor: "bg-blue-500"
                    },
                    {
                        name: "Ah",
                        label: "Ahrefs",
                        bgColor: "bg-red-500"
                    },
                    {
                        name: "Gt",
                        label: "GTM",
                        bgColor: "bg-blue-600"
                    }
                ]
            },
            {
                id: "social-media-manager",
                title: "Social Media Manager",
                subtitle: "Builds Your Online Community",
                skills: [
                    "Content Planning",
                    "Community Management",
                    "Influencer Outreach",
                    "Analytics",
                    "Paid Ads",
                    "Story Creation",
                    "Engagement",
                    "Trend Analysis"
                ],
                buttonText: "Hire Social Media Manager",
                toolIcons: [
                    {
                        name: "Ai",
                        label: "AI",
                        bgColor: "bg-orange-500"
                    },
                    {
                        name: "Fb",
                        label: "Facebook",
                        bgColor: "bg-blue-600"
                    },
                    {
                        name: "In",
                        label: "Instagram",
                        bgColor: "bg-pink-500"
                    }
                ]
            }
        ]
    },
    {
        id: "development",
        name: "Development",
        members: [
            {
                id: "frontend-developer",
                title: "Frontend Developer",
                subtitle: "Builds Beautiful User Interfaces",
                skills: [
                    "React",
                    "Next.js",
                    "TypeScript",
                    "Tailwind CSS",
                    "Responsive Design",
                    "Performance",
                    "Accessibility",
                    "Testing"
                ],
                buttonText: "Hire Frontend Developer",
                toolIcons: [
                    {
                        name: "R",
                        label: "React",
                        bgColor: "bg-blue-500"
                    },
                    {
                        name: "N",
                        label: "Next.js",
                        bgColor: "bg-black"
                    },
                    {
                        name: "Ts",
                        label: "TypeScript",
                        bgColor: "bg-blue-600"
                    }
                ]
            },
            {
                id: "backend-developer",
                title: "Backend Developer",
                subtitle: "Powers Your Digital Infrastructure",
                skills: [
                    "API Development",
                    "Database Design",
                    "Server Management",
                    "Security",
                    "Cloud Services",
                    "Microservices",
                    "DevOps",
                    "Scalability"
                ],
                buttonText: "Hire Backend Developer",
                toolIcons: [
                    {
                        name: "N",
                        label: "Node.js",
                        bgColor: "bg-green-500"
                    },
                    {
                        name: "Py",
                        label: "Python",
                        bgColor: "bg-yellow-500"
                    },
                    {
                        name: "Db",
                        label: "Database",
                        bgColor: "bg-blue-600"
                    }
                ]
            },
            {
                id: "fullstack-developer",
                title: "Full Stack Developer",
                subtitle: "End-to-End Development Solutions",
                skills: [
                    "Full Stack",
                    "Architecture",
                    "Integration",
                    "Deployment",
                    "CI/CD",
                    "Monitoring",
                    "Optimization",
                    "Maintenance"
                ],
                buttonText: "Hire Full Stack Developer",
                toolIcons: [
                    {
                        name: "R",
                        label: "React",
                        bgColor: "bg-blue-500"
                    },
                    {
                        name: "N",
                        label: "Node.js",
                        bgColor: "bg-green-500"
                    },
                    {
                        name: "Aw",
                        label: "AWS",
                        bgColor: "bg-orange-500"
                    }
                ]
            }
        ]
    },
    {
        id: "key-growth",
        name: "Key Growth",
        members: [
            {
                id: "growth-manager",
                title: "Growth Manager",
                subtitle: "Strategizes Your Path to Success",
                skills: [
                    "Growth Strategy",
                    "Analytics",
                    "A/B Testing",
                    "Funnel Optimization",
                    "Customer Acquisition",
                    "Retention",
                    "Revenue Growth",
                    "Market Research"
                ],
                buttonText: "Hire Growth Manager",
                toolIcons: [
                    {
                        name: "Ai",
                        label: "AI",
                        bgColor: "bg-orange-500"
                    },
                    {
                        name: "Ga",
                        label: "Analytics",
                        bgColor: "bg-blue-500"
                    },
                    {
                        name: "Cr",
                        label: "CRM",
                        bgColor: "bg-purple-500"
                    }
                ]
            },
            {
                id: "data-analyst",
                title: "Data Analyst",
                subtitle: "Turns Data Into Insights",
                skills: [
                    "Data Analysis",
                    "Reporting",
                    "Dashboards",
                    "Predictive Analytics",
                    "Data Visualization",
                    "KPI Tracking",
                    "Business Intelligence",
                    "Statistical Analysis"
                ],
                buttonText: "Hire Data Analyst",
                toolIcons: [
                    {
                        name: "Py",
                        label: "Python",
                        bgColor: "bg-yellow-500"
                    },
                    {
                        name: "Ga",
                        label: "Analytics",
                        bgColor: "bg-blue-500"
                    },
                    {
                        name: "Tb",
                        label: "Tableau",
                        bgColor: "bg-blue-600"
                    }
                ]
            },
            {
                id: "project-manager",
                title: "Project Manager",
                subtitle: "Keeps Everything On Track",
                skills: [
                    "Project Planning",
                    "Team Coordination",
                    "Timeline Management",
                    "Resource Allocation",
                    "Risk Management",
                    "Stakeholder Communication",
                    "Quality Assurance",
                    "Delivery"
                ],
                buttonText: "Hire Project Manager",
                toolIcons: [
                    {
                        name: "As",
                        label: "Asana",
                        bgColor: "bg-purple-500"
                    },
                    {
                        name: "J",
                        label: "Jira",
                        bgColor: "bg-blue-500"
                    },
                    {
                        name: "T",
                        label: "Trello",
                        bgColor: "bg-blue-400"
                    }
                ]
            }
        ]
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$stores$2f$useModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/stores/useModalStore.ts [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/icons'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$EmpoweredTeam$2f$empoweredTeamData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/EmpoweredTeam/empoweredTeamData.ts [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module './EmpoweredTeam.module.css'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const EmpoweredTeam = ()=>{
    _s();
    const [isDesktop, setIsDesktop] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("creative-design");
    const [activeMember, setActiveMember] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("brand-designer");
    // refs
    const stackCardsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const itemsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const scrollingFnRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scrollingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const animationFrameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scrollContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const openModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$stores$2f$useModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalStore"])({
        "EmpoweredTeam.useModalStore[openModal]": (state)=>state.openModal
    }["EmpoweredTeam.useModalStore[openModal]"]);
    // Helper functions
    const hasClass = (el, className)=>{
        if (el.classList) return el.classList.contains(className);
        else return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
    };
    const addClass = (el, className)=>{
        const classList = className.split(' ');
        if (el.classList) el.classList.add(classList[0]);
        else if (!hasClass(el, classList[0])) el.className += " " + classList[0];
        if (classList.length > 1) addClass(el, classList.slice(1).join(' '));
    };
    const removeClass = (el, className)=>{
        const classList = className.split(' ');
        if (el.classList) el.classList.remove(classList[0]);
        else if (hasClass(el, classList[0])) {
            const reg = new RegExp('(\\s|^)' + classList[0] + '(\\s|$)');
            el.className = el.className.replace(reg, ' ');
        }
        if (classList.length > 1) removeClass(el, classList.slice(1).join(' '));
    };
    const osHasReducedMotion = ()=>{
        if (!window.matchMedia) return false;
        const matchMediaObj = window.matchMedia('(prefers-reduced-motion: reduce)');
        if (matchMediaObj) return matchMediaObj.matches;
        return false;
    };
    // Stack Cards functions
    const setStackCards = ()=>{
        const element = stackCardsRef.current;
        if (!element) return;
        const items = itemsRef.current;
        if (!items || items.length === 0) return;
        // Reset all transformations if not desktop
        if (!isDesktop) {
            element.style.paddingBottom = '0px';
            for(let i = 0; i < items.length; i++){
                if (items[i]) {
                    items[i].style.transform = 'none';
                    items[i].classList.remove('service-scrollerItemContainer', 'stack-cards__item', 'js-stack-cards__item');
                    items[i].style.display = 'block';
                }
            }
            return;
        }
        // Desktop setup
        for(let i = 0; i < items.length; i++){
            if (items[i]) {
                items[i].style.display = 'block';
                items[i].style.transition = 'transform 0.1s ease-out';
                if (!items[i].classList.contains('service-scrollerItemContainer')) {
                    items[i].classList.add('service-scrollerItemContainer', 'stack-cards__item', 'js-stack-cards__item');
                }
            }
        }
        if (!items[0]) return;
        const marginYValue = getComputedStyle(element).getPropertyValue('--stack-cards-gap');
        const marginY = getIntegerFromProperty(marginYValue, element);
        const elementHeight = element.offsetHeight;
        const cardStyle = getComputedStyle(items[0]);
        const cardTop = Math.floor(parseFloat(cardStyle.getPropertyValue('top')));
        const cardHeight = Math.floor(parseFloat(cardStyle.getPropertyValue('height')));
        if (isNaN(marginY)) {
            element.style.paddingBottom = '0px';
        } else {
            element.style.paddingBottom = marginY * (items.length - 1) + 'px';
        }
        for(let i = 0; i < items.length; i++){
            if (items[i]) {
                if (isNaN(marginY)) {
                    items[i].style.transform = 'none';
                } else {
                    items[i].style.transform = `translateY(${marginY * i}px)`;
                }
            }
        }
    };
    const getIntegerFromProperty = (value, element)=>{
        const node = document.createElement('div');
        node.setAttribute('style', 'opacity:0; visbility: hidden;position: absolute; height:' + value);
        element.appendChild(node);
        const intValue = parseInt(getComputedStyle(node).getPropertyValue('height'));
        element.removeChild(node);
        return intValue;
    };
    const syncActiveByVisibility = ()=>{
        const list = stackCardsRef.current;
        if (!list) return;
        const cards = Array.from(list.querySelectorAll("li[id^='member-']"));
        if (!cards.length) return;
        const rootEl = scrollContainerRef.current;
        const rootRect = rootEl && rootEl.scrollHeight > rootEl.clientHeight ? rootEl.getBoundingClientRect() : new DOMRect(0, 0, window.innerWidth, window.innerHeight);
        let bestId = activeMember, best = 0;
        for (const el of cards){
            const r = el.getBoundingClientRect();
            const top = Math.max(r.top, rootRect.top);
            const bottom = Math.min(r.bottom, rootRect.bottom);
            const visible = Math.max(0, bottom - top);
            const ratio = r.height ? visible / r.height : 0;
            if (ratio > best) {
                best = ratio;
                bestId = el.id.replace('member-', '');
            }
        }
        if (bestId !== activeMember) {
            setActiveMember(bestId);
            // Update active category based on active member
            for (const category of __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$EmpoweredTeam$2f$empoweredTeamData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPOWERED_TEAM_DATA"]){
                if (category.members.some((m)=>m.id === bestId)) {
                    setActiveCategory(category.id);
                    break;
                }
            }
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmpoweredTeam.useEffect": ()=>{
            if (isDesktop) return;
            const root = scrollContainerRef.current ?? window;
            let raf = 0;
            const onScroll = {
                "EmpoweredTeam.useEffect.onScroll": ()=>{
                    cancelAnimationFrame(raf);
                    raf = requestAnimationFrame(syncActiveByVisibility);
                }
            }["EmpoweredTeam.useEffect.onScroll"];
            root.addEventListener('scroll', onScroll, {
                passive: true
            });
            window.addEventListener('resize', onScroll, {
                passive: true
            });
            syncActiveByVisibility();
            return ({
                "EmpoweredTeam.useEffect": ()=>{
                    root.removeEventListener('scroll', onScroll);
                    window.removeEventListener('resize', onScroll);
                    cancelAnimationFrame(raf);
                }
            })["EmpoweredTeam.useEffect"];
        }
    }["EmpoweredTeam.useEffect"], [
        isDesktop,
        activeMember
    ]);
    const maintainStackCardsScale = ()=>{
        if (!isDesktop) return;
        const element = stackCardsRef.current;
        if (!element) return;
        const items = itemsRef.current;
        if (!items || items.length === 0 || !items[0]) return;
        const marginYValue = getComputedStyle(element).getPropertyValue('--stack-cards-gap');
        const marginY = getIntegerFromProperty(marginYValue, element);
        if (isNaN(marginY)) return;
        const top = element.getBoundingClientRect().top;
        const cardStyle = getComputedStyle(items[0]);
        const cardTop = Math.floor(parseFloat(cardStyle.getPropertyValue('top')));
        const cardHeight = Math.floor(parseFloat(cardStyle.getPropertyValue('height')));
        for(let i = 0; i < items.length; i++){
            if (!items[i]) continue;
            const scrolling = cardTop - top - i * (cardHeight + marginY);
            if (scrolling > 0) {
                const scaling = i === items.length - 1 ? 1 : (cardHeight - scrolling * 0.05) / cardHeight;
                const boundedScaling = Math.max(0.7, Math.min(1, scaling));
                items[i].style.transform = `translateY(${marginY * i}px) scale(${boundedScaling})`;
            } else {
                items[i].style.transform = `translateY(${marginY * i}px)`;
            }
        }
    };
    const animateStackCards = ()=>{
        if (!isDesktop) {
            scrollingRef.current = false;
            syncActiveByVisibility();
            return;
        }
        const element = stackCardsRef.current;
        if (!element) return;
        const items = itemsRef.current;
        if (!items || items.length === 0 || !items[0]) {
            scrollingRef.current = false;
            return;
        }
        const marginYValue = getComputedStyle(element).getPropertyValue('--stack-cards-gap');
        const marginY = getIntegerFromProperty(marginYValue, element);
        if (isNaN(marginY)) {
            scrollingRef.current = false;
            return;
        }
        const top = element.getBoundingClientRect().top;
        const cardStyle = getComputedStyle(items[0]);
        const cardTop = Math.floor(parseFloat(cardStyle.getPropertyValue('top')));
        const cardHeight = Math.floor(parseFloat(cardStyle.getPropertyValue('height')));
        const elementHeight = element.offsetHeight;
        const windowHeight = window.innerHeight;
        if (cardTop - top + windowHeight - elementHeight - cardHeight + marginY + marginY * items.length > 0) {
            scrollingRef.current = false;
            return;
        }
        let bestIndex = 0;
        let bestDist = Infinity;
        for(let i = 0; i < items.length; i++){
            if (!items[i]) continue;
            const scrolling = cardTop - top - i * (cardHeight + marginY);
            if (scrolling > 0) {
                const scaling = i === items.length - 1 ? 1 : (cardHeight - scrolling * 0.05) / cardHeight;
                items[i].style.transform = `translateY(${marginY * i}px) scale(${scaling})`;
            } else {
                items[i].style.transform = `translateY(${marginY * i}px)`;
            }
            const dist = Math.abs(scrolling);
            if (dist < bestDist) {
                bestDist = dist;
                bestIndex = i;
            }
        }
        const activeItems = getActiveCategoryMembers();
        if (activeItems[bestIndex]) {
            const newActiveId = activeItems[bestIndex].id;
            if (newActiveId !== activeMember) {
                setActiveMember(newActiveId);
            }
        }
        scrollingRef.current = false;
    };
    const stackCardsScrolling = ()=>{
        if (!isDesktop || scrollingRef.current) return;
        scrollingRef.current = true;
        animationFrameRef.current = requestAnimationFrame(animateStackCards);
    };
    const initStackCardsEffect = ()=>{
        if (stackCardsRef.current && itemsRef.current && itemsRef.current.length > 0) {
            setStackCards();
            if (!isDesktop) return;
            window.addEventListener('scroll', stackCardsScrolling);
        }
    };
    const cleanupStackCards = ()=>{
        if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
        }
        window.removeEventListener('scroll', stackCardsScrolling);
    };
    const getActiveCategoryMembers = ()=>{
        const category = __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$EmpoweredTeam$2f$empoweredTeamData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPOWERED_TEAM_DATA"].find((cat)=>cat.id === activeCategory);
        return category ? category.members : [];
    };
    const handleCategoryClick = (categoryId)=>{
        setActiveCategory(categoryId);
        const category = __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$EmpoweredTeam$2f$empoweredTeamData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPOWERED_TEAM_DATA"].find((cat)=>cat.id === categoryId);
        if (category && category.members.length > 0) {
            setActiveMember(category.members[0].id);
            const target = document.getElementById(`member-${category.members[0].id}`);
            if (target) {
                const scroller = scrollContainerRef.current;
                if (scroller && scroller.scrollHeight > scroller.clientHeight) {
                    const targetRect = target.getBoundingClientRect();
                    const scrollerRect = scroller.getBoundingClientRect();
                    const current = scroller.scrollTop;
                    const delta = targetRect.top - scrollerRect.top;
                    scroller.scrollTo({
                        top: current + delta,
                        behavior: "smooth"
                    });
                    return;
                }
                const y = window.scrollY + target.getBoundingClientRect().top - 80;
                window.scrollTo({
                    top: y,
                    behavior: "smooth"
                });
            }
        }
    };
    const handleMemberClick = (memberId)=>{
        setActiveMember(memberId);
        const target = document.getElementById(`member-${memberId}`);
        if (!target) return;
        const scroller = scrollContainerRef.current;
        if (scroller && scroller.scrollHeight > scroller.clientHeight) {
            const targetRect = target.getBoundingClientRect();
            const scrollerRect = scroller.getBoundingClientRect();
            const current = scroller.scrollTop;
            const delta = targetRect.top - scrollerRect.top;
            scroller.scrollTo({
                top: current + delta,
                behavior: "smooth"
            });
            return;
        }
        const y = window.scrollY + target.getBoundingClientRect().top - 80;
        window.scrollTo({
            top: y,
            behavior: "smooth"
        });
    };
    // Get card elements for visibility detection
    const getCardEls = ()=>{
        const activeMembers = getActiveCategoryMembers();
        return activeMembers.map((member)=>document.getElementById(`member-${member.id}`)).filter(Boolean);
    };
    const ratioInRoot = (rect, rootRect)=>{
        const top = Math.max(rect.top, rootRect.top);
        const bottom = Math.min(rect.bottom, rootRect.bottom);
        const visible = Math.max(0, bottom - top);
        return rect.height > 0 ? visible / rect.height : 0;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmpoweredTeam.useEffect": ()=>{
            const rootEl = scrollContainerRef.current ?? null;
            const getRootRect = {
                "EmpoweredTeam.useEffect.getRootRect": ()=>rootEl && rootEl.scrollHeight > rootEl.clientHeight ? rootEl.getBoundingClientRect() : new DOMRect(0, 0, window.innerWidth, window.innerHeight)
            }["EmpoweredTeam.useEffect.getRootRect"];
            let raf = 0;
            const selectMostVisible = {
                "EmpoweredTeam.useEffect.selectMostVisible": ()=>{
                    const cards = getCardEls();
                    if (!cards.length) return;
                    const rootRect = getRootRect();
                    let bestId = activeMember;
                    let best = 0;
                    for (const el of cards){
                        const r = el.getBoundingClientRect();
                        const ratio = ratioInRoot(r, rootRect);
                        if (ratio > best) {
                            best = ratio;
                            bestId = el.id.replace('member-', '');
                        }
                    }
                    if (bestId !== activeMember && best >= 0.35) {
                        setActiveMember(bestId);
                        for (const category of __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$EmpoweredTeam$2f$empoweredTeamData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPOWERED_TEAM_DATA"]){
                            if (category.members.some({
                                "EmpoweredTeam.useEffect.selectMostVisible": (m)=>m.id === bestId
                            }["EmpoweredTeam.useEffect.selectMostVisible"])) {
                                setActiveCategory(category.id);
                                break;
                            }
                        }
                    }
                }
            }["EmpoweredTeam.useEffect.selectMostVisible"];
            const onScroll = {
                "EmpoweredTeam.useEffect.onScroll": ()=>{
                    cancelAnimationFrame(raf);
                    raf = requestAnimationFrame(selectMostVisible);
                }
            }["EmpoweredTeam.useEffect.onScroll"];
            (rootEl ?? window).addEventListener("scroll", onScroll, {
                passive: true
            });
            window.addEventListener("resize", onScroll, {
                passive: true
            });
            selectMostVisible();
            return ({
                "EmpoweredTeam.useEffect": ()=>{
                    (rootEl ?? window).removeEventListener("scroll", onScroll);
                    window.removeEventListener("resize", onScroll);
                    cancelAnimationFrame(raf);
                }
            })["EmpoweredTeam.useEffect"];
        }
    }["EmpoweredTeam.useEffect"], [
        scrollContainerRef.current,
        activeCategory,
        activeMember
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmpoweredTeam.useEffect": ()=>{
            const handleResize = {
                "EmpoweredTeam.useEffect.handleResize": ()=>{
                    const desktop = window.innerWidth >= 1024;
                    setIsDesktop(desktop);
                    cleanupStackCards();
                    setTimeout({
                        "EmpoweredTeam.useEffect.handleResize": ()=>{
                            initStackCardsEffect();
                        }
                    }["EmpoweredTeam.useEffect.handleResize"], 100);
                }
            }["EmpoweredTeam.useEffect.handleResize"];
            const desktop = window.innerWidth >= 1024;
            setIsDesktop(desktop);
            if (!osHasReducedMotion()) {
                setTimeout({
                    "EmpoweredTeam.useEffect": ()=>{
                        initStackCardsEffect();
                    }
                }["EmpoweredTeam.useEffect"], 200);
            }
            let resizeTimeout;
            const resizeListener = {
                "EmpoweredTeam.useEffect.resizeListener": ()=>{
                    clearTimeout(resizeTimeout);
                    resizeTimeout = setTimeout(handleResize, 500);
                }
            }["EmpoweredTeam.useEffect.resizeListener"];
            window.addEventListener('resize', resizeListener);
            return ({
                "EmpoweredTeam.useEffect": ()=>{
                    cleanupStackCards();
                    window.removeEventListener('resize', resizeListener);
                    if (resizeTimeout) clearTimeout(resizeTimeout);
                }
            })["EmpoweredTeam.useEffect"];
        }
    }["EmpoweredTeam.useEffect"], [
        isDesktop,
        activeCategory
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmpoweredTeam.useEffect": ()=>{
            const updateServiceScrollerClass = {
                "EmpoweredTeam.useEffect.updateServiceScrollerClass": ()=>{
                    const el = document.getElementById("empoweredTeamScrollerArea");
                    if (!el) return;
                    if (window.innerWidth > 1024) {
                        removeClass(el, "service-scrollerArea");
                    } else {
                        addClass(el, "service-scrollerArea");
                    }
                }
            }["EmpoweredTeam.useEffect.updateServiceScrollerClass"];
            updateServiceScrollerClass();
            window.addEventListener("resize", updateServiceScrollerClass);
            return ({
                "EmpoweredTeam.useEffect": ()=>{
                    window.removeEventListener("resize", updateServiceScrollerClass);
                }
            })["EmpoweredTeam.useEffect"];
        }
    }["EmpoweredTeam.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmpoweredTeam.useEffect": ()=>{
            const timer = setTimeout({
                "EmpoweredTeam.useEffect.timer": ()=>{
                    if (stackCardsRef.current) {
                        itemsRef.current = Array.from(stackCardsRef.current.getElementsByClassName('js-stack-cards__item'));
                        if (!isDesktop && itemsRef.current.length > 0) {
                            setStackCards();
                        }
                    }
                }
            }["EmpoweredTeam.useEffect.timer"], 100);
            return ({
                "EmpoweredTeam.useEffect": ()=>clearTimeout(timer)
            })["EmpoweredTeam.useEffect"];
        }
    }["EmpoweredTeam.useEffect"], [
        isDesktop,
        activeCategory
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmpoweredTeam.useEffect": ()=>{
            if (!isDesktop) return;
            const intervalId = setInterval({
                "EmpoweredTeam.useEffect.intervalId": ()=>{
                    if (!scrollingRef.current) {
                        maintainStackCardsScale();
                    }
                }
            }["EmpoweredTeam.useEffect.intervalId"], 16);
            return ({
                "EmpoweredTeam.useEffect": ()=>clearInterval(intervalId)
            })["EmpoweredTeam.useEffect"];
        }
    }["EmpoweredTeam.useEffect"], [
        isDesktop,
        activeCategory
    ]);
    const activeMembers = getActiveCategoryMembers();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${styles.empoweredTeamSection} sectionPadding bg-[#020016]`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "sectionPaddingCase pt-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container-fluid",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "row align-items-center justify-content-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-md-10 text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "tracking-[-0.02em] mb-6 lg:leading-[4rem] md:text-5xl font-semibold headingSize lineHeight-1 text-center text-white",
                                    children: [
                                        "Meet Your ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[#0fdac2]",
                                            children: "AI-Empowered"
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                            lineNumber: 487,
                                            columnNumber: 27
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        " Team Behind Your Growth"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                    lineNumber: 486,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-white/80 text-lg max-w-4xl mx-auto mb-12",
                                    children: "When you bring on your Smart Marketing AI Team, you're not hiring freelancers — you're unlocking a complete digital department. Each role blends human expertise with AI precision to move your marketing faster, smarter, and farther than ever. Every deliverable builds lasting value for your business, from the first design to full-scale automation."
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                    lineNumber: 489,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                            lineNumber: 485,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                        lineNumber: 484,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "col-xl-5 col-lg-12 col-md-12",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-md-3 rounded scroll2 right-column hideOnipad",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: styles.categoryNav,
                                                children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$EmpoweredTeam$2f$empoweredTeamData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPOWERED_TEAM_DATA"].map((category, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: `${styles.categoryButton} ${activeCategory === category.id ? styles.active : ''}`,
                                                                onClick: ()=>handleCategoryClick(category.id),
                                                                children: category.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                lineNumber: 503,
                                                                columnNumber: 25
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            index < __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$EmpoweredTeam$2f$empoweredTeamData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPOWERED_TEAM_DATA"].length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: styles.categoryDivider
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                lineNumber: 510,
                                                                columnNumber: 27
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, category.id, true, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                        lineNumber: 502,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                lineNumber: 500,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "d-flex align-items-start mt-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "d-flex nav d-grid flex-column nav-pills me-3",
                                                    id: "v-pills-tab",
                                                    role: "tablist",
                                                    "aria-orientation": "vertical",
                                                    children: activeMembers.map((member)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            className: `nav-link scrollAnchor ps-3 ${activeMember === member.id ? "active2" : ""}`,
                                                            href: `#member-${member.id}`,
                                                            onClick: (e)=>{
                                                                e.preventDefault();
                                                                handleMemberClick(member.id);
                                                            },
                                                            children: member.title
                                                        }, member.id, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                            lineNumber: 525,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)))
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                    lineNumber: 518,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                lineNumber: 517,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                        lineNumber: 498,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                    lineNumber: 497,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "col-xl-7 col-lg-12 col-md-12 text-light",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-4 tabBgbox",
                                        ref: scrollContainerRef,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "service-scrollerArea stack-cards js-stack-cards",
                                            id: "empoweredTeamScrollerArea",
                                            ref: stackCardsRef,
                                            style: {
                                                '--stack-cards-gap': '40px'
                                            },
                                            children: activeMembers.map((member)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "service-scrollerItemContainer stack-cards__item js-stack-cards__item",
                                                    id: `member-${member.id}`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: styles.memberCard,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: styles.cardContent,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: styles.cardLeft,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                            className: styles.memberTitle,
                                                                            children: member.title
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                            lineNumber: 559,
                                                                            columnNumber: 31
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            className: styles.memberSubtitle,
                                                                            children: member.subtitle
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                            lineNumber: 560,
                                                                            columnNumber: 31
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: styles.skillsGrid,
                                                                            children: member.skills.map((skill, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: styles.skillTag,
                                                                                    children: skill
                                                                                }, idx, false, {
                                                                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                    lineNumber: 564,
                                                                                    columnNumber: 35
                                                                                }, ("TURBOPACK compile-time value", void 0)))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                            lineNumber: 562,
                                                                            columnNumber: 31
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            className: styles.hireButton,
                                                                            onClick: openModal,
                                                                            children: [
                                                                                member.buttonText,
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ArrowRightIcon, {
                                                                                    style: {
                                                                                        fill: "#020016"
                                                                                    }
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                    lineNumber: 575,
                                                                                    columnNumber: 33
                                                                                }, ("TURBOPACK compile-time value", void 0))
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                            lineNumber: 570,
                                                                            columnNumber: 31
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                    lineNumber: 558,
                                                                    columnNumber: 29
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: styles.cardRight,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: styles.characterContainer,
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: styles.rocketBackground
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                lineNumber: 581,
                                                                                columnNumber: 33
                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                src: "/assets/images/man-img.webp",
                                                                                alt: member.title,
                                                                                width: 300,
                                                                                height: 400,
                                                                                className: styles.characterImage,
                                                                                priority: false
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                lineNumber: 582,
                                                                                columnNumber: 33
                                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: styles.toolIcons,
                                                                                children: member.toolIcons.map((tool, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: styles.toolIcon,
                                                                                        style: {
                                                                                            top: idx === 0 ? '10%' : idx === 1 ? '70%' : '70%',
                                                                                            right: idx === 0 ? '10%' : idx === 1 ? '10%' : '70%'
                                                                                        },
                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: `${styles.toolIconCircle} ${tool.bgColor}`,
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                className: styles.toolIconText,
                                                                                                children: tool.name
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                                lineNumber: 601,
                                                                                                columnNumber: 41
                                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                            lineNumber: 600,
                                                                                            columnNumber: 39
                                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                                    }, idx, false, {
                                                                                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                        lineNumber: 592,
                                                                                        columnNumber: 37
                                                                                    }, ("TURBOPACK compile-time value", void 0)))
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                                lineNumber: 590,
                                                                                columnNumber: 33
                                                                            }, ("TURBOPACK compile-time value", void 0))
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                        lineNumber: 580,
                                                                        columnNumber: 31
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                                    lineNumber: 579,
                                                                    columnNumber: 29
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                            lineNumber: 557,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                        lineNumber: 556,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, member.id, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                                    lineNumber: 551,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                            lineNumber: 544,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                        lineNumber: 543,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                                    lineNumber: 542,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                            lineNumber: 496,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                        lineNumber: 495,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
                lineNumber: 483,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
            lineNumber: 482,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/EmpoweredTeam/EmpoweredTeam.tsx",
        lineNumber: 481,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(EmpoweredTeam, "e3w5zV8k89/abjoM8PH7LupqrIk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$stores$2f$useModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useModalStore"]
    ];
});
_c = EmpoweredTeam;
const __TURBOPACK__default__export__ = EmpoweredTeam;
var _c;
__turbopack_context__.k.register(_c, "EmpoweredTeam");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=startupsadvisory_src_68e533e7._.js.map