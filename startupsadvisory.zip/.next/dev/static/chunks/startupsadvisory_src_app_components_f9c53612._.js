(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BRAND_LOGOS",
    ()=>BRAND_LOGOS
]);
const BRAND_LOGOS = [
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "heroBrand": "LogosSlider-module__ElbhZa__heroBrand",
  "logoItems": "LogosSlider-module__ElbhZa__logoItems",
  "logosSliderSection": "LogosSlider-module__ElbhZa__logosSliderSection",
  "scroll-left": "LogosSlider-module__ElbhZa__scroll-left",
});
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-client] (css module)");
"use client";
;
;
;
;
const LogosSlider = ({ className })=>{
    // Duplicate logos for seamless infinite loop
    const duplicatedLogos = __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"] && __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"].length > 0 ? [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"],
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_LOGOS"]
    ] : [];
    if (duplicatedLogos.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logosSliderSection} ${className} py-4 md:py-6`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroBrand} overflow-hidden whitespace-nowrap relative w-full mx-auto`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].logoItems} inline-flex`,
                children: duplicatedLogos.map((logo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: logo.src,
                        alt: logo.alt,
                        className: "mx-4",
                        width: 200,
                        height: 100
                    }, `${logo.alt}-${index}`, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                        lineNumber: 23,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                lineNumber: 21,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = LogosSlider;
const __TURBOPACK__default__export__ = LogosSlider;
var _c;
__turbopack_context__.k.register(_c, "LogosSlider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "content": "HeroBanner-module__HJajBq__content",
  "float": "HeroBanner-module__HJajBq__float",
  "heroBackground": "HeroBanner-module__HJajBq__heroBackground",
});
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/icons/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-client] (css module)");
"use client";
;
;
;
;
;
;
function HeroBanner({ headline, headlineHighlight, subheadline, description, ctaButton, className = "" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heroBackground} relative sectionPadding overflow-hidden ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "2xl",
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content} relative z-10`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center text-center gap-6 md:gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-5xl lg:text-6xl font-extrabold max-w-3xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-white",
                                    children: headline
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 27,
                                    columnNumber: 13
                                }, this),
                                headlineHighlight && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: headlineHighlight
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 30,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false),
                                subheadline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white",
                                        children: subheadline
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 35,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-base md:text-lg lg:text-xl text-white/80 max-w-3xl leading-relaxed",
                            children: description
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: ctaButton.href,
                                variant: ctaButton.variant || "secondary",
                                size: "lg",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowRightIcon"], {}, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 51,
                                    columnNumber: 21
                                }, void 0),
                                iconPosition: "right",
                                children: ctaButton.text
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                lineNumber: 47,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "mt-16"
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = HeroBanner;
var _c;
__turbopack_context__.k.register(_c, "HeroBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "closeButton": "VideoPopup-module__JCSAFG__closeButton",
  "fadeIn": "VideoPopup-module__JCSAFG__fadeIn",
  "popupContent": "VideoPopup-module__JCSAFG__popupContent",
  "popupOverlay": "VideoPopup-module__JCSAFG__popupOverlay",
  "sizeLg": "VideoPopup-module__JCSAFG__sizeLg",
  "sizeMd": "VideoPopup-module__JCSAFG__sizeMd",
  "sizeSm": "VideoPopup-module__JCSAFG__sizeSm",
  "sizeXl": "VideoPopup-module__JCSAFG__sizeXl",
  "sizeXxl": "VideoPopup-module__JCSAFG__sizeXxl",
  "videoContainer": "VideoPopup-module__JCSAFG__videoContainer",
  "videoIframe": "VideoPopup-module__JCSAFG__videoIframe",
});
}),
"[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const VideoPopup = ({ isOpen, onClose, videoUrl, videoTitle = "Video player", size = "lg" })=>{
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPopup.useEffect": ()=>{
            if (isOpen) {
                document.body.style.overflow = "hidden";
            } else {
                document.body.style.overflow = "unset";
            }
            return ({
                "VideoPopup.useEffect": ()=>{
                    document.body.style.overflow = "unset";
                }
            })["VideoPopup.useEffect"];
        }
    }["VideoPopup.useEffect"], [
        isOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VideoPopup.useEffect": ()=>{
            const handleEscape = {
                "VideoPopup.useEffect.handleEscape": (e)=>{
                    if (e.key === "Escape") {
                        onClose();
                    }
                }
            }["VideoPopup.useEffect.handleEscape"];
            if (isOpen) {
                window.addEventListener("keydown", handleEscape);
            }
            return ({
                "VideoPopup.useEffect": ()=>{
                    window.removeEventListener("keydown", handleEscape);
                }
            })["VideoPopup.useEffect"];
        }
    }["VideoPopup.useEffect"], [
        isOpen,
        onClose
    ]);
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].popupOverlay} ${isOpen ? __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].fadeIn : ""}`,
        onClick: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].popupContent} ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"][`size${size === "sm" ? "Sm" : size === "md" ? "Md" : size === "lg" ? "Lg" : size === "xl" ? "Xl" : "Xxl"}`]}`,
            onClick: (e)=>e.stopPropagation(),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClose,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeButton,
                    "aria-label": "Close video",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "w-6 h-6",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M6 18L18 6M6 6l12 12"
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                            lineNumber: 74,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoContainer,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                        src: videoUrl || "https://www.youtube.com/embed/dQw4w9WgXcQ",
                        title: videoTitle,
                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                        allowFullScreen: true,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoIframe
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                        lineNumber: 85,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
            lineNumber: 58,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(VideoPopup, "3ubReDTFssvu4DHeldAg55cW/CI=");
_c = VideoPopup;
const __TURBOPACK__default__export__ = VideoPopup;
var _c;
__turbopack_context__.k.register(_c, "VideoPopup");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "backgroundDecoration": "ProfessionalOnline-module__4_2b0a__backgroundDecoration",
  "videoCard": "ProfessionalOnline-module__4_2b0a__videoCard",
});
}),
"[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/VideoPopup/VideoPopup.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const ProfessionalOnline = ()=>{
    _s();
    const [isPopupOpen, setIsPopupOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const contentBars = [
        {
            label: "Content",
            progress: 85,
            color: "purple"
        },
        {
            label: "Content",
            progress: 70,
            color: "teal"
        },
        {
            label: "Content",
            progress: 90,
            color: "purple"
        },
        {
            label: "Content",
            progress: 65,
            color: "teal"
        },
        {
            label: "Content",
            progress: 80,
            color: "purple"
        },
        {
            label: "Content",
            progress: 75,
            color: "teal"
        },
        {
            label: "Content",
            progress: 88,
            color: "purple"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-16 md:py-24 relative overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        maxWidth: "xl",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative z-10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "Local "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 30,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-[#0fdac2]",
                                                    children: "Businesses "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 31,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "Struggle to Stay Visible"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 32,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 29,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-white/80 text-lg md:text-xl mb-8 leading-relaxed",
                                            children: "You're great at what you do, but your marketing falls behind. Agencies cost a fortune. Freelancers disappear."
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 34,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: contentBars.map((bar, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-white/70 text-sm font-medium",
                                                                children: [
                                                                    bar.label,
                                                                    " :"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 44,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 43,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-full h-3 bg-[#1a1a2e] rounded-full overflow-hidden",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: `h-full rounded-full transition-all duration-1000 ${bar.color === "purple" ? "bg-[#643bff]" : "bg-[#0fdac2]"}`,
                                                                style: {
                                                                    width: `${bar.progress}%`
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 49,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 48,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, index, true, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 42,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 40,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                    lineNumber: 28,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative z-10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative group cursor-pointer",
                                            onClick: ()=>setIsPopupOpen(true),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].videoCard} relative rounded-2xl overflow-hidden transition-all duration-300 group-hover:shadow-[#643bff]/60`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "aspect-video bg-gradient-to-br from-[#1a1a2e] to-[#0a0a1a] flex items-center relative overflow-hidden",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "absolute left-0 top-0 bottom-0 w-[12rem] md:w-[14rem] lg:w-[16rem]",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: "/assets/images/person-img.webp",
                                                                        alt: "Person",
                                                                        fill: true,
                                                                        className: "object-cover object-center",
                                                                        priority: true,
                                                                        sizes: "(max-width: 768px) 12rem, (max-width: 1024px) 14rem, 16rem"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                        lineNumber: 72,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute inset-0 bg-gradient-to-r from-[#020016]/60 to-transparent"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                        lineNumber: 80,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 71,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "absolute right-0 top-0 bottom-0 left-[12rem] md:left-[14rem] lg:left-[16rem] flex items-center px-4 md:px-6 lg:px-8",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-white/90 text-xs md:text-sm lg:text-base font-medium leading-relaxed drop-shadow-lg",
                                                                    children: "Your Smart Marketing AI Team op de e a behind -the-scenes planning promotions, creating visuals."
                                                                }, void 0, false, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                    lineNumber: 85,
                                                                    columnNumber: 23
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 84,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                        lineNumber: 69,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "absolute inset-0 flex items-center justify-center pointer-events-none",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-20 h-20 md:w-24 md:h-24 bg-[#643bff] rounded-full flex items-center justify-center shadow-lg shadow-[#643bff]/50 transition-all duration-300 group-hover:scale-110 group-hover:shadow-[#643bff]/70 z-10 pointer-events-auto",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-10 h-10 md:w-12 md:h-12 text-white ml-1",
                                                                fill: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    d: "M8 5v14l11-7z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                    lineNumber: 99,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                                lineNumber: 94,
                                                                columnNumber: 23
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                            lineNumber: 93,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                        lineNumber: 92,
                                                        columnNumber: 19
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                lineNumber: 67,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-3xl md:text-4xl lg:text-5xl font-extrabold mt-8 text-center lg:text-left leading-tight",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "The Simple Way to Look "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 108,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-[#0fdac2]",
                                                    children: "Professional "
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 109,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-white",
                                                    children: "Online"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                                    lineNumber: 110,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                            lineNumber: 107,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                                    lineNumber: 64,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$ProfessionalOnline$2f$ProfessionalOnline$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backgroundDecoration
                    }, void 0, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                        lineNumber: 117,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$VideoPopup$2f$VideoPopup$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isPopupOpen,
                onClose: ()=>setIsPopupOpen(false),
                videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                videoTitle: "Professional Online Video",
                size: "lg"
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/ProfessionalOnline/ProfessionalOnline.tsx",
                lineNumber: 121,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(ProfessionalOnline, "vFErrUU1qYQoaBmFpaEBY5pk8jE=");
_c = ProfessionalOnline;
const __TURBOPACK__default__export__ = ProfessionalOnline;
var _c;
__turbopack_context__.k.register(_c, "ProfessionalOnline");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=startupsadvisory_src_app_components_f9c53612._.js.map