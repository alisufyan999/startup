__turbopack_load_page_chunks__("/_error", [
  "static/chunks/3325b_next_dist_compiled_9ed4b6e6._.js",
  "static/chunks/3325b_next_dist_shared_lib_8079fa83._.js",
  "static/chunks/3325b_next_dist_client_f299ab4f._.js",
  "static/chunks/3325b_next_dist_074468aa._.js",
  "static/chunks/3325b_next_error_ddda8ece.js",
  "static/chunks/[next]_entry_page-loader_ts_798ffc80._.js",
  "static/chunks/3325b_react-dom_f4652edb._.js",
  "static/chunks/3325b_9cbcc4be._.js",
  "static/chunks/[root-of-the-server]__4ec52b48._.js",
  "static/chunks/startupsadvisory_pages__error_2da965e7._.js",
  "static/chunks/turbopack-startupsadvisory_pages__error_784223b1._.js"
])
