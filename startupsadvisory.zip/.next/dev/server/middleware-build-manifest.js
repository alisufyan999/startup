globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/3325b_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d70e8481._.js",
    "static/chunks/3325b_next_dist_compiled_react-dom_9cf6d6b7._.js",
    "static/chunks/3325b_next_dist_compiled_react-server-dom-turbopack_3143ea8c._.js",
    "static/chunks/3325b_next_dist_compiled_next-devtools_index_595d37a3.js",
    "static/chunks/3325b_next_dist_compiled_8f5e9a70._.js",
    "static/chunks/3325b_next_dist_client_e3640edb._.js",
    "static/chunks/3325b_next_dist_a06dd7df._.js",
    "static/chunks/3325b_@swc_helpers_cjs_cd478a28._.js",
    "static/chunks/startupsadvisory_a0ff3932._.js",
    "static/chunks/turbopack-startupsadvisory_d5f32f95._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];