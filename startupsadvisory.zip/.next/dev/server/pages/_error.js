var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/3325b_9996751d._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/3325b_40395ba1._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/3325b_next_e52681f0._.js")
R.m("[project]/startupsadvisory/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/startupsadvisory/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/startupsadvisory/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/startupsadvisory/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/startupsadvisory/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/startupsadvisory/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/startupsadvisory/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/startupsadvisory/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
