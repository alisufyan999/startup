module.exports = [
"[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BRAND_LOGOS",
    ()=>BRAND_LOGOS
]);
const BRAND_LOGOS = [
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    },
    {
        src: "/assets/images/logos/1.webp",
        alt: "Yahoo News"
    },
    {
        src: "/assets/images/logos/2.webp",
        alt: "Logotype"
    },
    {
        src: "/assets/images/logos/3.webp",
        alt: "Duragas Abastible"
    },
    {
        src: "/assets/images/logos/4.webp",
        alt: "Maxton Design"
    },
    {
        src: "/assets/images/logos/5.webp",
        alt: "Forbes"
    },
    {
        src: "/assets/images/logos/6.webp",
        alt: "Bloomberg"
    }
];
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "heroBrand": "LogosSlider-module__ElbhZa__heroBrand",
  "logoItems": "LogosSlider-module__ElbhZa__logoItems",
  "logosSliderSection": "LogosSlider-module__ElbhZa__logosSliderSection",
  "scroll-left": "LogosSlider-module__ElbhZa__scroll-left",
});
}),
"[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/logosData.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
const LogosSlider = ({ className })=>{
    // Duplicate logos for seamless infinite loop
    const duplicatedLogos = __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BRAND_LOGOS"] && __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BRAND_LOGOS"].length > 0 ? [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BRAND_LOGOS"],
        ...__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$logosData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BRAND_LOGOS"]
    ] : [];
    if (duplicatedLogos.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].logosSliderSection} ${className} py-4 md:py-6`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].heroBrand} overflow-hidden whitespace-nowrap relative w-full mx-auto`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].logoItems} inline-flex`,
                children: duplicatedLogos.map((logo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: logo.src,
                        alt: logo.alt,
                        className: "mx-4",
                        width: 200,
                        height: 100
                    }, `${logo.alt}-${index}`, false, {
                        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                        lineNumber: 23,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
                lineNumber: 21,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = LogosSlider;
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "content": "HeroBanner-module__HJajBq__content",
  "float": "HeroBanner-module__HJajBq__float",
  "heroBackground": "HeroBanner-module__HJajBq__heroBackground",
});
}),
"[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/icons/index.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/LogosSlider/LogosSlider.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
;
;
function HeroBanner({ headline, headlineHighlight, subheadline, description, ctaButton, className = "" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].heroBackground} relative sectionPadding overflow-hidden ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "2xl",
                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$HeroBanner$2f$HeroBanner$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].content} relative z-10`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center text-center gap-6 md:gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-5xl lg:text-6xl font-extrabold max-w-3xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-white",
                                    children: headline
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 27,
                                    columnNumber: 13
                                }, this),
                                headlineHighlight && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#0fdac2]",
                                        children: headlineHighlight
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 30,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false),
                                subheadline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white",
                                        children: subheadline
                                    }, void 0, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                        lineNumber: 35,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-base md:text-lg lg:text-xl text-white/80 max-w-3xl leading-relaxed",
                            children: description
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: ctaButton.href,
                                variant: ctaButton.variant || "secondary",
                                size: "lg",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ArrowRightIcon"], {}, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                    lineNumber: 51,
                                    columnNumber: 21
                                }, void 0),
                                iconPosition: "right",
                                children: ctaButton.text
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                                lineNumber: 47,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$LogosSlider$2f$LogosSlider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                className: "mt-16"
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/HeroBanner/HeroBanner.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=startupsadvisory_src_app_components_9a26f57a._.js.map