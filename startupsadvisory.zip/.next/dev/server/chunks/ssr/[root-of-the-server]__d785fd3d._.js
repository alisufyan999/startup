module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/startupsadvisory/src/app/constants.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CALENDLY_SECTION",
    ()=>CALENDLY_SECTION,
    "COMPANY_INFO",
    ()=>COMPANY_INFO,
    "FAQ_DATA",
    ()=>FAQ_DATA,
    "FAQ_SECTION",
    ()=>FAQ_SECTION,
    "FOOTER_LINKS",
    ()=>FOOTER_LINKS,
    "GROWTH_GUIDES",
    ()=>GROWTH_GUIDES,
    "HERO_BANNER",
    ()=>HERO_BANNER,
    "NAVIGATION_LINKS",
    ()=>NAVIGATION_LINKS,
    "PROFESSIONAL_ONLINE",
    ()=>PROFESSIONAL_ONLINE,
    "REVIEWS_SECTION",
    ()=>REVIEWS_SECTION,
    "SOCIAL_MEDIA_LINKS",
    ()=>SOCIAL_MEDIA_LINKS,
    "TECHNOLOGIES_SECTION",
    ()=>TECHNOLOGIES_SECTION,
    "TOP_BANNER",
    ()=>TOP_BANNER
]);
const COMPANY_INFO = {
    logo: "/assets/images/logo.svg",
    email: "info@startupsadvisory.ai",
    phone: "+1 (555) 123-4567",
    address: "123 Startup Street, Innovation City, IC 12345",
    companyName: "Startups ADVISORY.Ai",
    website: "https://startupsadvisory.ai"
};
const NAVIGATION_LINKS = [
    {
        label: "Solutions",
        href: "/solutions"
    },
    {
        label: "How it Works",
        href: "/how-it-works"
    },
    {
        label: "Pricing",
        href: "/pricing"
    },
    {
        label: "Your Ai Agent",
        href: "/ai-agent"
    }
];
const TOP_BANNER = {
    show: true,
    emoji: "🚀",
    text: "Big News: We are now a Public Company",
    buttonText: "Know More →",
    buttonLink: "/big-news"
};
const HERO_BANNER = {
    headline: "Your ",
    headlineHighlight: "Smart Marketing AI ",
    subheadline: "Team — Ready to Run Your Digital Work for You",
    className: "bottomZero",
    description: "Finally, marketing that moves at the speed of your business. Your Smart Marketing AI Team plans, designs, writes, and posts — so you stay focused on serving clients.",
    ctaButton: {
        text: "Let's Get Your Marketing Handled",
        href: "/get-started",
        variant: "secondary"
    }
};
const FAQ_SECTION = {
    title: {
        part1: "Frequently Asked",
        part2: "Questions"
    },
    subtitle: "Answers to the most common local-business questions about how this team fits your workflow."
};
const FAQ_DATA = [
    {
        question: "What is a Smart Marketing AI Team?",
        answer: "It's a full digital department designers, marketers, developers, and a Key Growth Manager supported by AI to deliver every marketing task your business needs fast and on brand."
    },
    {
        question: "How does this team work with my business?",
        answer: "Our Smart Marketing AI Team integrates seamlessly with your existing workflow. We work as an extension of your business, handling all marketing tasks while you focus on serving your clients. The team communicates regularly, follows your brand guidelines, and delivers results that align with your business objectives."
    },
    {
        question: "What types of businesses use Smart Marketing AI Teams?",
        answer: "Smart Marketing AI Teams are ideal for local businesses, startups, agencies, and companies of all sizes that need professional marketing support without the overhead of a full in-house team. Whether you're in retail, services, technology, or any other industry, our AI-powered team adapts to your specific needs."
    },
    {
        question: "Do I need to purchase any AI tools myself?",
        answer: "No, you don't need to purchase any AI tools. We provide all the necessary AI-powered tools and platforms as part of our service. Our team uses advanced AI technology to handle content creation, design, strategy, and execution - all included in your package."
    },
    {
        question: "How quickly can my team start producing results?",
        answer: "Your Smart Marketing AI Team can start producing results within days of onboarding. We begin by understanding your brand, goals, and requirements, then immediately start creating content, managing campaigns, and executing your marketing strategy. Most clients see initial results within the first week."
    },
    {
        question: "Who manages quality and performance?",
        answer: "Quality and performance are managed by our experienced Key Growth Manager who oversees all team activities. They ensure that every piece of content, campaign, and strategy meets your brand standards and business objectives. Regular performance reviews and optimizations are part of our standard service."
    },
    {
        question: "What if I already have a marketing team?",
        answer: "Our Smart Marketing AI Team works perfectly alongside your existing marketing team. We can handle overflow work, specialized projects, or specific tasks that your team doesn't have capacity for. Many businesses use us to augment their current team's capabilities and scale their marketing efforts."
    },
    {
        question: "Can the team handle my industry's specific needs?",
        answer: "Yes, absolutely. Our Smart Marketing AI Team is trained to work across various industries and can adapt to your specific industry requirements, compliance needs, and target audience. During onboarding, we deep-dive into your industry specifics to ensure all content and strategies are tailored accordingly."
    },
    {
        question: "How is communication handled?",
        answer: "Communication is handled through your dedicated Key Growth Manager, who serves as your primary point of contact. You'll have regular check-ins, access to a shared dashboard for project tracking, and direct communication channels for urgent needs. We ensure you're always in the loop and can provide feedback easily."
    },
    {
        question: "What does the onboarding process look like?",
        answer: "The onboarding process is straightforward and typically takes 2-3 days. We start with a discovery call to understand your business, brand, goals, and preferences. Then we set up your brand guidelines, content calendar, and communication channels. Your team begins working on your marketing tasks immediately after onboarding is complete."
    }
];
const FOOTER_LINKS = {
    column1: [
        {
            label: "Digital Consultation",
            href: "/digital-consultation"
        },
        {
            label: "Staff Augmentation",
            href: "/staff-augmentation"
        },
        {
            label: "About",
            href: "/about"
        },
        {
            label: "Contact",
            href: "/contact"
        }
    ],
    column2: [
        {
            label: "How it works",
            href: "/how-it-works"
        },
        {
            label: "In the press",
            href: "/press"
        },
        {
            label: "Affiliate",
            href: "/affiliate"
        },
        {
            label: "Brand",
            href: "/brand"
        }
    ],
    column3: [
        {
            label: "Privacy Policy",
            href: "/privacy-policy"
        },
        {
            label: "Data Security",
            href: "/data-security"
        },
        {
            label: "Terms of Use",
            href: "/terms-of-use"
        },
        {
            label: "New Secret Project",
            href: "/secret-project"
        }
    ]
};
const SOCIAL_MEDIA_LINKS = [
    {
        name: "LinkedIn",
        icon: "linkedin",
        href: "https://linkedin.com"
    },
    {
        name: "Instagram",
        icon: "instagram",
        href: "https://instagram.com"
    },
    {
        name: "Facebook",
        icon: "facebook",
        href: "https://facebook.com"
    },
    {
        name: "GitHub",
        icon: "github",
        href: "https://github.com"
    },
    {
        name: "Website",
        icon: "globe",
        href: "https://startupsadvisory.ai"
    },
    {
        name: "YouTube",
        icon: "youtube",
        href: "https://youtube.com"
    }
];
const PROFESSIONAL_ONLINE = {
    heading: {
        part1: "Local ",
        part2: "Businesses ",
        part3: "Struggle to Stay Visible"
    },
    description: "You're great at what you do, but your marketing falls behind. Agencies cost a fortune. Freelancers disappear.",
    contentBars: [
        {
            label: "Content",
            progress: 85,
            color: "purple"
        },
        {
            label: "Content",
            progress: 70,
            color: "teal"
        },
        {
            label: "Content",
            progress: 90,
            color: "purple"
        },
        {
            label: "Content",
            progress: 65,
            color: "teal"
        },
        {
            label: "Content",
            progress: 80,
            color: "purple"
        },
        {
            label: "Content",
            progress: 75,
            color: "teal"
        },
        {
            label: "Content",
            progress: 88,
            color: "purple"
        }
    ],
    video: {
        thumbnail: "/assets/images/person-img.webp",
        overlayText: "Your Smart Marketing AI Team op de e a behind -the-scenes planning promotions, creating visuals.",
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        videoTitle: "Professional Online Video"
    },
    bottomHeading: {
        part1: "The Simple Way to Look ",
        part2: "Professional ",
        part3: "Online"
    }
};
const REVIEWS_SECTION = {
    heading: {
        part1: "Real Owners, ",
        part2: "Real Results"
    },
    subtitle: "From roofers to electricians, small businesses now show up online with consistent, professional marketing — without lifting a finger.",
    ctaText: "See how Smart Marketing AI Teams turned invisibility into daily inquiries",
    ratingBadges: [
        {
            platform: "Trustpilot",
            rating: "4.4/5",
            bgColor: "#00B67A",
            textColor: "#ffffff",
            logoColor: "white"
        },
        {
            platform: "Google",
            rating: "4.4/5",
            bgColor: "#ffffff",
            textColor: "#000000",
            logoColor: "colorful"
        },
        {
            platform: "Facebook",
            rating: "4.4/5",
            bgColor: "#ffffff",
            textColor: "#000000",
            logoColor: "colorful"
        }
    ],
    reviews: [
        {
            id: 1,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 16, 2025",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond, and always on top of everything. The whole process was smooth and stress-free because he handled tasks efficiently and with great attention to detail.",
            isVideo: false
        },
        {
            id: 2,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 16, 2006",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond, and always on top of everything. The whole process was smooth and stress-free because he handled tasks efficiently and with great attention to detail. website manager Solomon.",
            isVideo: false
        },
        {
            id: 3,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 15, 2025",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond, and always on top of everything. The whole process was smooth and stress-free because he handled tasks efficiently and with great attention to detail website manager Solomon.My website manager Solomon, did an excellent job! He was very professional, quick to respond. and always on top of everything. The whole process was smooth and stress froc bocause he handled tasks efficiently and with great attention to detail.",
            isVideo: false
        },
        {
            id: 4,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 16, 2025",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond,",
            isVideo: false
        },
        {
            id: 5,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 15, 2005",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond,",
            isVideo: false
        },
        {
            id: 6,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 2026",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond, and always on top of everything. The whole process was smooth and stress-free because he handled tasks efficiently and with great attention to detail. website manager Solomon.",
            isVideo: false
        },
        {
            id: 7,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 15, 2025",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, website manager Solomon.",
            isVideo: true,
            videoThumbnail: "/assets/images/video-review-thumb.webp",
            videoDuration: "0:00",
            videoUrl: "/assets/videos/videoplayback.mp4"
        },
        {
            id: 8,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 16, 2005",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond,",
            isVideo: false
        },
        {
            id: 9,
            name: "Vanessa Mls",
            initials: "VM",
            source: "Trustpilot",
            date: "Sep 16, 2025",
            rating: 5,
            text: "My website manager Solomon, did an excellent job! He was very professional, quick to respond,",
            isVideo: false
        }
    ]
};
const GROWTH_GUIDES = [
    {
        id: "1",
        image: "/assets/images/hero.webp",
        category: "Shopify Agent",
        title: "AI Agents Benefit From Data Quality Validation And More...",
        date: "Nov 10, 2025",
        readTime: "6 min read",
        excerpt: "Imagine launching a digital workforce of intelligent agents that operate on unstructured data — validated, enriched, and ready to act.",
        href: "/blog/ai-agents-data-quality"
    },
    {
        id: "2",
        image: "/assets/images/hero.webp",
        category: "Shopify Agent",
        title: "AI Agents Benefit From Data Quality Validation And More...",
        date: "Nov 10, 2025",
        readTime: "7 min read",
        excerpt: "Imagine launching a digital workforce of intelligent agents that operate on unstructured data — validated, enriched, and ready to act.",
        href: "/blog/ai-agents-data-quality-2"
    },
    {
        id: "3",
        image: "/assets/images/hero.webp",
        category: "Shopify Agent",
        title: "AI Agents Benefit From Data Quality Validation And More...",
        date: "Nov 10, 2025",
        readTime: "5 min read",
        excerpt: "Imagine launching a digital workforce of intelligent agents that operate on unstructured data — validated, enriched, and ready to act.",
        href: "/blog/ai-agents-data-quality-3"
    },
    {
        id: "4",
        image: "/assets/images/hero.webp",
        category: "Shopify Agent",
        title: "AI Agents Benefit From Data Quality Validation And More...",
        date: "Nov 10, 2025",
        readTime: "5 min read",
        excerpt: "Imagine launching a digital workforce of intelligent agents that operate on unstructured data — validated, enriched, and ready to act.",
        href: "/blog/ai-agents-data-quality-3"
    },
    {
        id: "5",
        image: "/assets/images/hero.webp",
        category: "Shopify Agent",
        title: "AI Agents Benefit From Data Quality Validation And More...",
        date: "Nov 10, 2025",
        readTime: "5 min read",
        excerpt: "Imagine launching a digital workforce of intelligent agents that operate on unstructured data — validated, enriched, and ready to act.",
        href: "/blog/ai-agents-data-quality-3"
    },
    {
        id: "6",
        image: "/assets/images/hero.webp",
        category: "Shopify Agent",
        title: "AI Agents Benefit From Data Quality Validation And More...",
        date: "Nov 10, 2025",
        readTime: "5 min read",
        excerpt: "Imagine launching a digital workforce of intelligent agents that operate on unstructured data — validated, enriched, and ready to act.",
        href: "/blog/ai-agents-data-quality-3"
    }
];
const CALENDLY_SECTION = {
    heading: {
        part1: "Let's Talk About Taking",
        part2: "Marketing",
        part3: "Off Your Plate"
    },
    description: "Book a quick video call to see how your Smart Marketing AI Team can free you to run jobs while your digital presence runs itself",
    buttonText: "Free Up Your Time",
    buttonHref: "/get-started",
    calendlyUrl: "https://calendly.com/your-username/meeting",
    calendlyText: "In minutes, you'll see examples of what your team can handle — ads, social, website, graphics — and how it all works together seamlessly"
};
const TECHNOLOGIES_SECTION = {
    heading: {
        part1: "The Smart Marketing",
        part2: "AI Stack",
        part3: " — $48,000+ Worth of Tools Working for You"
    },
    description: "Your Smart Marketing AI Team doesn't just come with talent — it comes with a fully loaded AI ecosystem. From creative design to analytics automation, every task is powered by premium, enterprise-grade AI tools other businesses pay thousands for individually. You get all of it included — no setup, no license, no hassle.",
    tabs: [
        {
            id: "creative",
            label: "Creative & Design",
            value: "$12,000+ Annual Value"
        },
        {
            id: "marketing",
            label: "Marketing & Growth",
            value: "$15,000+ Annual Value"
        },
        {
            id: "development",
            label: "Development",
            value: "$10,000+ Annual Value"
        },
        {
            id: "growth",
            label: "Key Growth",
            value: "$11,000+ Annual Value"
        }
    ],
    tools: {
        creative: [
            {
                id: 1,
                name: "Kaiber",
                icon: "K",
                iconColor: "#8b5cf6"
            },
            {
                id: 2,
                name: "Illustrator",
                icon: "Ai",
                iconColor: "#ff6b35"
            },
            {
                id: 3,
                name: "After Effects",
                icon: "Ae",
                iconColor: "#8b5cf6"
            },
            {
                id: 4,
                name: "Midjourney (Pro)",
                icon: "🎨",
                iconColor: "#0fdac2"
            },
            {
                id: 5,
                name: "Figma + FigJam AI",
                icon: "F",
                iconColor: "#ff6b9d"
            },
            {
                id: 6,
                name: "Magic Studio Pro",
                icon: "M",
                iconColor: "#0fdac2"
            },
            {
                id: 7,
                name: "Photoshop",
                icon: "Ps",
                iconColor: "#4285f4"
            },
            {
                id: 8,
                name: "Runway ML (Enterprise)",
                icon: "R",
                iconColor: "#0fdac2"
            },
            {
                id: 9,
                name: "ElevenLabs",
                icon: "||",
                iconColor: "#0fdac2"
            },
            {
                id: 10,
                name: "Pika Labs",
                icon: "🐰",
                iconColor: "#ffffff"
            },
            {
                id: 11,
                name: "Canv",
                icon: "C",
                iconColor: "#0fdac2"
            }
        ],
        marketing: [
            {
                id: 1,
                name: "Google Ads AI",
                icon: "G",
                iconColor: "#4285f4"
            },
            {
                id: 2,
                name: "Facebook Ads Manager",
                icon: "f",
                iconColor: "#1877f2"
            },
            {
                id: 3,
                name: "HubSpot AI",
                icon: "H",
                iconColor: "#ff7a59"
            },
            {
                id: 4,
                name: "Mailchimp AI",
                icon: "M",
                iconColor: "#ffe01b"
            },
            {
                id: 5,
                name: "Semrush AI",
                icon: "S",
                iconColor: "#ff6b35"
            }
        ],
        development: [
            {
                id: 1,
                name: "GitHub Copilot",
                icon: "GH",
                iconColor: "#ffffff"
            },
            {
                id: 2,
                name: "Vercel AI",
                icon: "V",
                iconColor: "#000000"
            },
            {
                id: 3,
                name: "Codeium",
                icon: "C",
                iconColor: "#0fdac2"
            },
            {
                id: 4,
                name: "Cursor AI",
                icon: "Cu",
                iconColor: "#643bff"
            }
        ],
        growth: [
            {
                id: 1,
                name: "Analytics AI",
                icon: "A",
                iconColor: "#0fdac2"
            },
            {
                id: 2,
                name: "SEO AI Tools",
                icon: "S",
                iconColor: "#ff6b35"
            },
            {
                id: 3,
                name: "Content AI",
                icon: "C",
                iconColor: "#8b5cf6"
            }
        ]
    }
};
}),
"[project]/startupsadvisory/src/app/components/Container.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Container
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function Container({ children, className = "", maxWidth = "xl" }) {
    const maxWidthClasses = {
        sm: "max-w-screen-sm",
        md: "max-w-screen-md",
        lg: "max-w-screen-lg",
        xl: "max-w-screen-xl",
        "2xl": "max-w-screen-2xl",
        full: "max-w-full"
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `w-full mx-auto px-4 sm:px-6 lg:px-8 ${maxWidthClasses[maxWidth]} ${className}`,
        children: children
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/Container.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
}),
"[project]/startupsadvisory/src/app/components/Button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
;
;
function Button({ variant = "primary", size = "md", children, className = "", icon, iconPosition = "right", ...props }) {
    const baseClasses = "inline-flex items-center justify-center gap-3 font-medium transition-colors rounded-full px-6";
    const variantClasses = {
        primary: "bg-[#0fdac2] text-[#020016] hover:bg-[#0ec5b0]",
        secondary: "bg-[#643bff] text-white hover:bg-[#7c5aff]",
        outline: "border-2 border-[#0fdac2] text-[#0fdac2] hover:bg-[#0fdac2] hover:text-[#020016]",
        dark: "bg-[#020016] text-white hover:bg-[#0a0a1a]",
        light: "bg-white text-[#020016] hover:bg-gray-100"
    };
    const sizeClasses = {
        sm: "px-3 py-1.5 text-xs",
        md: "px-4 py-2 text-sm",
        lg: "px-6 py-3 text-base"
    };
    const iconElement = icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        children: icon
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/Button.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
    const combinedClasses = `${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`;
    if ("href" in props && props.href) {
        const { href, ...linkProps } = props;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            className: combinedClasses,
            ...linkProps,
            children: [
                iconPosition === "left" && iconElement,
                children,
                iconPosition === "right" && iconElement
            ]
        }, void 0, true, {
            fileName: "[project]/startupsadvisory/src/app/components/Button.tsx",
            lineNumber: 38,
            columnNumber: 7
        }, this);
    }
    const buttonProps = props;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: combinedClasses,
        ...buttonProps,
        children: [
            iconPosition === "left" && iconElement,
            children,
            iconPosition === "right" && iconElement
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/Button.tsx",
        lineNumber: 48,
        columnNumber: 5
    }, this);
}
}),
"[project]/startupsadvisory/src/app/components/icons/index.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowRightIcon",
    ()=>ArrowRightIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const ArrowRightIcon = ({ style })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "18",
        height: "18",
        viewBox: "0 0 20 20",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "m17.707 9.293-5-5a.999.999 0 1 0-1.414 1.414L14.586 9H3a1 1 0 1 0 0 2h11.586l-3.293 3.293a.999.999 0 1 0 1.414 1.414l5-5a1 1 0 0 0 0-1.414",
            fill: style?.fill || "#fff"
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/icons/index.tsx",
            lineNumber: 5,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/icons/index.tsx",
        lineNumber: 4,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
}),
"[project]/startupsadvisory/src/app/components/TopHeader.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TopHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/icons/index.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function TopHeader() {
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TOP_BANNER"].show) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "absolute top-0 left-0 right-0 z-50 flex items-center justify-center w-full py-2 bg-transparent backdrop-blur-sm",
        style: {
            willChange: "transform"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            maxWidth: "2xl",
            className: "px-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between w-full rounded-full px-4 py-2 backdrop-blur-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 flex-1 justify-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-2xl",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TOP_BANNER"].emoji
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
                            lineNumber: 16,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-white text-sm md:text-base font-medium ",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TOP_BANNER"].text
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
                            lineNumber: 17,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TOP_BANNER"].buttonLink,
                            variant: "secondary",
                            size: "sm",
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ArrowRightIcon"], {}, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
                                lineNumber: 24,
                                columnNumber: 21
                            }, void 0),
                            iconPosition: "right",
                            className: "whitespace-nowrap ml-2",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TOP_BANNER"].buttonText.replace(" →", "")
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
                            lineNumber: 20,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
                    lineNumber: 15,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
                lineNumber: 14,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/TopHeader.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
}),
"[project]/startupsadvisory/src/app/components/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/icons/index.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function Header() {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "absolute top-12 left-0 right-0 z-50 flex items-center justify-center w-full py-4 bg-transparent",
        style: {
            willChange: "transform"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                maxWidth: "xl",
                className: "px-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "flex items-center justify-between w-full rounded-full px-4 md:px-6 py-4 bg-[#02001c] backdrop-blur-sm shadow-lg border border-[#4e4989]",
                    style: {
                        minHeight: "64px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col relative",
                                style: {
                                    width: 100,
                                    height: 40
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["COMPANY_INFO"].logo,
                                    alt: "Logo",
                                    width: 100,
                                    height: 40,
                                    priority: true,
                                    style: {
                                        objectFit: "contain"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                    lineNumber: 19,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                lineNumber: 18,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                            lineNumber: 17,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden md:flex items-center gap-6 flex-1 justify-center",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NAVIGATION_LINKS"].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: link.href,
                                    className: "text-white text-sm font-medium hover:text-[#0fdac2] transition-colors",
                                    children: link.label
                                }, link.href, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                    lineNumber: 32,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden md:flex",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/demo",
                                variant: "primary",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$icons$2f$index$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ArrowRightIcon"], {
                                    style: {
                                        fill: "#000"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                    lineNumber: 46,
                                    columnNumber: 21
                                }, void 0),
                                iconPosition: "right",
                                children: "Book A Demo"
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                lineNumber: 43,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setIsMobileMenuOpen(!isMobileMenuOpen),
                            className: "md:hidden flex flex-col gap-1.5 p-2",
                            "aria-label": "Toggle menu",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `block w-6 h-0.5 bg-white transition-all ${isMobileMenuOpen ? "rotate-45 translate-y-2" : ""}`
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                    lineNumber: 59,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `block w-6 h-0.5 bg-white transition-all ${isMobileMenuOpen ? "opacity-0" : ""}`
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                    lineNumber: 64,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `block w-6 h-0.5 bg-white transition-all ${isMobileMenuOpen ? "-rotate-45 -translate-y-2" : ""}`
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                    lineNumber: 69,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            isMobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-full left-0 right-0 w-full bg-[#0a0a1a] border-t border-[#1a1a2e]/50 md:hidden z-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col px-4 py-4 gap-4",
                    children: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NAVIGATION_LINKS"].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: link.href,
                                className: "text-white text-base font-medium hover:text-[#0fdac2] transition-colors py-2",
                                onClick: ()=>setIsMobileMenuOpen(false),
                                children: link.label
                            }, link.href, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                                lineNumber: 82,
                                columnNumber: 15
                            }, this)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "/demo",
                            variant: "primary",
                            size: "md",
                            icon: "→",
                            iconPosition: "right",
                            className: "mt-2",
                            onClick: ()=>setIsMobileMenuOpen(false),
                            children: "Book A Demo"
                        }, void 0, false, {
                            fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                    lineNumber: 80,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
                lineNumber: 79,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/startupsadvisory/src/app/components/Header.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
}),
"[project]/startupsadvisory/src/app/components/Footer/Footer.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "footer": "Footer-module__O7lNWW__footer",
  "footerContent": "Footer-module__O7lNWW__footerContent",
  "footerLink": "Footer-module__O7lNWW__footerLink",
  "footerlogo": "Footer-module__O7lNWW__footerlogo",
  "leftSection": "Footer-module__O7lNWW__leftSection",
  "linkColumn": "Footer-module__O7lNWW__linkColumn",
  "logoContainer": "Footer-module__O7lNWW__logoContainer",
  "logoGradient": "Footer-module__O7lNWW__logoGradient",
  "logoSubtext": "Footer-module__O7lNWW__logoSubtext",
  "logoText": "Footer-module__O7lNWW__logoText",
  "rightSection": "Footer-module__O7lNWW__rightSection",
  "rocketIcon": "Footer-module__O7lNWW__rocketIcon",
  "socialIcon": "Footer-module__O7lNWW__socialIcon",
  "socialIcons": "Footer-module__O7lNWW__socialIcons",
});
}),
"[project]/startupsadvisory/src/app/components/Footer/Footer.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Container.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/startupsadvisory/src/app/components/Footer/Footer.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
function Footer() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].footer,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Container$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            maxWidth: "xl",
            className: "px-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].footerContent,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].leftSection,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].logoContainer,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/assets/images/logo.webp",
                                    className: `img-fluid ${__TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].footerlogo}`
                                }, void 0, false, {
                                    fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                    lineNumber: 16,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                lineNumber: 15,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].socialIcons,
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SOCIAL_MEDIA_LINKS"].map((social, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: social.href,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].socialIcon,
                                        "aria-label": social.name,
                                        children: [
                                            social.icon === "linkedin" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 24 24",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                    lineNumber: 37,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                lineNumber: 31,
                                                columnNumber: 21
                                            }, this),
                                            social.icon === "instagram" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 24 24",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                lineNumber: 41,
                                                columnNumber: 21
                                            }, this),
                                            social.icon === "facebook" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 24 24",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                    lineNumber: 57,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                lineNumber: 51,
                                                columnNumber: 21
                                            }, this),
                                            social.icon === "github" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 24 24",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                    lineNumber: 67,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                lineNumber: 61,
                                                columnNumber: 21
                                            }, this),
                                            social.icon === "globe" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 24 24",
                                                fill: "none",
                                                stroke: "currentColor",
                                                strokeWidth: "2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                        cx: "12",
                                                        cy: "12",
                                                        r: "10"
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                        lineNumber: 79,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                        x1: "2",
                                                        y1: "12",
                                                        x2: "22",
                                                        y2: "12"
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                        lineNumber: 80,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"
                                                    }, void 0, false, {
                                                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                        lineNumber: 81,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                lineNumber: 71,
                                                columnNumber: 21
                                            }, this),
                                            social.icon === "youtube" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                width: "20",
                                                height: "20",
                                                viewBox: "0 0 24 24",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"
                                                }, void 0, false, {
                                                    fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                    lineNumber: 91,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                                lineNumber: 85,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                        lineNumber: 22,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                lineNumber: 20,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                        lineNumber: 13,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].rightSection,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].linkColumn,
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FOOTER_LINKS"].column1.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: link.href,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].footerLink,
                                        children: link.label
                                    }, index, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                        lineNumber: 104,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                lineNumber: 102,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].linkColumn,
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FOOTER_LINKS"].column2.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: link.href,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].footerLink,
                                        children: link.label
                                    }, index, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                        lineNumber: 117,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                lineNumber: 115,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].linkColumn,
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FOOTER_LINKS"].column3.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: link.href,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$startupsadvisory$2f$src$2f$app$2f$components$2f$Footer$2f$Footer$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].footerLink,
                                        children: link.label
                                    }, index, false, {
                                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                        lineNumber: 130,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                                lineNumber: 128,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
                lineNumber: 11,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
            lineNumber: 10,
            columnNumber: 8
        }, this)
    }, void 0, false, {
        fileName: "[project]/startupsadvisory/src/app/components/Footer/Footer.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__d785fd3d._.js.map